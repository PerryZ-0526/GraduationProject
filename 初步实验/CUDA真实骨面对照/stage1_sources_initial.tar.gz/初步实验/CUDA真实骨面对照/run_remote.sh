#!/usr/bin/env bash
# 固定线程预算和北京时间，全部GPU实验串行，失败即停止。
set -euo pipefail
export TZ=Asia/Shanghai
export PATH=/root/autodl-tmp/graduation_project/venv/bin:/usr/local/cuda/bin:$PATH
export CUDA_PATH=/usr/local/cuda
export OMP_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=4
export MKL_NUM_THREADS=4
export QT_QPA_PLATFORM=offscreen
cd /root/autodl-tmp/graduation_project/stage1
python 初步实验/局部适用域与核显计算/test_local.py
python 初步实验/边界过渡带联合重建/test_joint.py
python 初步实验/真实骨面共边拼接/test_stitch.py
python 初步实验/真实骨面高度图验证/test_projection.py
python 初步实验/局部区域重建阶段一/test_patch.py
python 初步实验/CUDA真实骨面对照/test_cuda.py
python 初步实验/CUDA真实骨面对照/run_comparison.py
