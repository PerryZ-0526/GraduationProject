#pragma once

#include <assert.h>
#include <cuda_runtime_api.h>
#include <cstdint>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "rxmesh/handle.h"
#include "rxmesh/patch_info.h"
#include "rxmesh/types.h"

#include "rxmesh/context.h"
#include "rxmesh/diff/util.h"
#include "rxmesh/matrix/dense_matrix.h"

#include <Eigen/Dense>

class RXMeshTest;

namespace rxmesh {

class RXMeshStatic;

/**
 * @brief Base untyped attributes used as an interface for attribute container
 */
class AttributeBase
{
    friend class ::RXMeshTest;

   public:
    AttributeBase() = default;

    virtual const char* get_name() const = 0;

    virtual void release(locationT location = LOCATION_ALL) = 0;

    virtual void release_name() = 0;

    virtual ~AttributeBase() = default;
};

/**
 * @brief  Here we manage the attributes on top of the mesh. An attributes is
 * attached to mesh element (e.g., vertices, edges, faces, or tets). largely
 * inspired by
 * https://github.com/gunrock/gunrock/blob/master/gunrock/util/array_utils.cuh
 * It is discouraged to use Attribute directly in favor of using
 * add_X_attributes() from RXMeshStatic where X is vertex, edge, face, or tet.
 * This way, the user does not have to specify the number of mesh elements or
 * deallocate/release the Attribute (attribute garbage collection is managed by
 * RXMeshStatic)
 * @tparam T type of the attribute
 * @tparam HandleT One of VertexHandle, EdgeHandle, FaceHandle, or TetHandle
 */
template <class T, typename HandleT>
class Attribute : public AttributeBase
{
    template <typename S, typename H>
    friend class ReduceHandle;

   public:
    using HandleType = HandleT;
    using Type       = T;

    /**
     * @brief Default constructor which initializes all pointers to nullptr
     */
    __device__ __host__ __forceinline__ Attribute()
        : AttributeBase(),
          m_rxmesh(nullptr),
          m_h_patches_info(nullptr),
          m_d_patches_info(nullptr),
          m_name(nullptr),
          m_num_attributes(0),
          m_num_elements(0),
          m_allocated(LOCATION_NONE),
          m_h_data(nullptr),
          m_d_data(nullptr),
          m_h_offsets(nullptr),
          m_d_offsets(nullptr),
          m_max_num_patches(0),
          m_layout(AoS),
          m_total_bytes(0),
          m_h_linear_id_element_prefix(nullptr),
          m_d_linear_id_element_prefix(nullptr),
          m_external_device_buffer(false)
    {
    }

    /**
     * @brief Main constructor to be used by RXMeshStatic not directly by the
     * user
     * @param name of the attribute
     * @param num_attributes number of attribute per face
     * @param location where the attribute to be allocated
     * @param layout memory layout in case of num_attributes>1
     * @param rxmesh pointer to the RXMeshStatic instance
     */
    __host__ explicit Attribute(const char*    name,
                                const uint32_t num_attributes,
                                locationT      location,
                                const layoutT  layout,
                                RXMeshStatic*  rxmesh);

    T& operator()(size_t i, size_t j = 0);

    T& operator()(size_t i, size_t j = 0) const;

    /** @brief Number of rows (mesh elements) */
    size_t rows() const;

    /** @brief Number of columns (attributes per element) */
    size_t cols() const;

    /** @brief Total number of mesh elements (vertices, edges, or faces) */
    uint32_t size() const;


    /**
     * @brief get the total number of bytes used for allocation
     */
    size_t get_total_bytes() const;

    /**
     * @brief convert the attributes stored into a dense matrix where number of
     * rows represent the number of mesh elements of this attribute and number
     * of columns is the number of attributes
     * @tparam Order storage order (Eigen::ColMajor or Eigen::RowMajor)
     */
    template <int Order = Eigen::ColMajor>
    std::shared_ptr<DenseMatrix<T, Order>> to_matrix() const;

    /**
     * @brief copy a dense matrix to this attribute. The copying happens on the
     * host side, i.e., we copy the content of mat which is on the host to this
     * attribute on the host side
     * @tparam Order storage order of the input matrix
     * @param mat dense matrix to copy from
     */
    template <int Order>
    void from_matrix(DenseMatrix<T, Order>* mat);

    /**
     * @brief get the number of elements in a patch. The element type
     * corresponds to the template HandleT
     * @param p the patch id
     */
    __host__ __device__ __forceinline__ uint32_t size(const uint32_t p) const
    {
#ifdef __CUDA_ARCH__
        return m_d_patches_info[p].get_num_elements<HandleT>()[0];
#else
        return m_h_patches_info[p].get_num_elements<HandleT>()[0];
#endif
    }

    /**
     * @brief get maximum number of elements in a patch. The element type
     * corresponds to the template HandleT
     * @param p the patch id
     */
    __host__ __device__ __forceinline__ uint32_t
    capacity(const uint32_t p) const
    {
#ifdef __CUDA_ARCH__
        return m_d_patches_info[p].get_capacity<HandleT>();
#else
        return m_h_patches_info[p].get_capacity<HandleT>();
#endif
    }

    /**
     * @brief Get patch info for patch p
     */
    __host__ __device__ __forceinline__ const PatchInfo& get_patch_info(
        const uint32_t p) const
    {
#ifdef __CUDA_ARCH__
        return m_d_patches_info[p];
#else
        return m_h_patches_info[p];
#endif
    }


    __host__ __device__ __forceinline__ uint32_t pitch_x() const
    {
        return (m_layout == AoS) ? m_num_attributes : 1;
    }


    __host__ __device__ __forceinline__ uint32_t pitch_y(const uint32_t p) const
    {
        if (m_layout == AoS) {
            return 1;
        } else if (m_layout == SoA) {
            return m_num_elements;
        } else {
            assert(m_layout == AoSoA);
            return capacity(p);
        }
    }

    Attribute(const Attribute& rhs) = default;

    virtual ~Attribute() = default;

    /**
     * @brief Release the name allocation.     
     */
    void release_name() override;

    /**
     * @brief Get the name of the attribute
     */
    const char* get_name() const;

    /**
     * @brief get the number of attributes per mesh element
     */
    __host__ __device__ __forceinline__ uint32_t get_num_attributes() const
    {
        return m_num_attributes;
    }

    /**
     * @brief Flag that indicates where the memory is allocated
     */
    __host__ __device__ __forceinline__ locationT get_allocated() const
    {
        return m_allocated;
    }

    /**
     * @brief return the memory layout
     */
    __host__ __device__ __forceinline__ layoutT get_layout() const
    {
        return m_layout;
    }

    /**
     * @brief Check if attribute is allocated on device
     */
    __host__ __device__ __forceinline__ bool is_device_allocated() const
    {
        return ((m_allocated & DEVICE) == DEVICE);
    }

    /**
     * @brief Check if attribute is allocated on host
     */
    __host__ __device__ __forceinline__ bool is_host_allocated() const
    {
        return ((m_allocated & HOST) == HOST);
    }

    /**
     * @brief Return the raw storage pointer for a host or device
     * allocation.
     */
    __host__ __device__ T* data(locationT location = DEVICE) const
    {
        if ((location & HOST) == HOST) {
            return m_h_data;
        }

        if ((location & DEVICE) == DEVICE) {
            return m_d_data;
        }

        assert(1 != 1);
        return nullptr;
    }

    /**
     * @brief Number of T values in the raw allocation.
     */
    __host__ __device__ size_t storage_size() const
    {
        return m_total_bytes / sizeof(T);
    }

    /**
     * @brief True when the raw storage is a global column-major
     * matrix.
     */
    __host__ __device__ bool is_tensor_layout() const
    {
        return m_layout == SoA;
    }

    /**
     * @brief True when the device storage points at memory owned by an
     * external party (e.g., a PyTorch tensor). In that case this attribute
     * never allocates or frees the device pointer.
     */
    __host__ __device__ bool is_external_device_buffer() const
    {
        return m_external_device_buffer;
    }

    /**
     * @brief Point the device storage at memory owned by somebody else.
     *
     * This is meant mainly for interop with external array frameworks that
     * already hold a buffer matching this attribute's true SoA (global
     * column-major) layout. The caller keeps ownership and must guarantee that
     * ptr stays valid for as long as this attribute reads or writes through
     * it. Only supported for SoA (tensor) layout, since that is the only layout
     * with a well defined global memory layout (that is independent of the
     * RXMesh patches)      
     * @param ptr device pointer holding size()
     * get_num_attributes() values
     * @param capacity_bytes accessible bytes
     * beginning at ptr
     * @return true on success and false on validation
     * failure
     */
    bool attach_device_buffer(T* ptr, size_t capacity_bytes)
    {
        if (m_layout != SoA) {
            RXMESH_ERROR(
                "Attribute::attach_device_buffer() is only supported for "
                "true SoA (tensor) layout attributes.");
            return false;
        }

        const size_t required_bytes =
            sizeof(T) * size_t(m_num_elements) * size_t(m_num_attributes);

        if (required_bytes != 0 && ptr == nullptr) {
            RXMESH_ERROR(
                "Attribute::attach_device_buffer() received a null pointer "
                "for a non-empty attribute.");
            return false;
        }

        if (capacity_bytes < required_bytes) {
            RXMESH_ERROR(
                "Attribute::attach_device_buffer() received {} bytes but the "
                "attribute requires at least {} bytes.",
                capacity_bytes,
                required_bytes);
            return false;
        }

        if (ptr != nullptr &&
            reinterpret_cast<std::uintptr_t>(ptr) % alignof(T) != 0) {
            RXMESH_ERROR(
                "Attribute::attach_device_buffer() received a pointer that is "
                "not aligned for the attribute value type.");
            return false;
        }

        if (ptr != nullptr) {
            cudaPointerAttributes external_attributes{};

            CUDA_ERROR(cudaPointerGetAttributes(&external_attributes, ptr));

#if CUDART_VERSION >= 10000
            if (external_attributes.type != cudaMemoryTypeDevice) {
#else
            if (external_attributes.memoryType != cudaMemoryTypeDevice) {
#endif
                RXMESH_ERROR(
                    "Attribute::attach_device_buffer() requires device "
                    "memory.");
                return false;
            }
        }

        // drop whatever we currently own on the device
        release(DEVICE);

        // SoA does not use the offset buffer, but this also refreshes
        // m_total_bytes so storage_size()/get_total_bytes() stay correct.
        allocate_offset();

        if (ptr == nullptr) {
            return true;
        }

        m_d_data                 = ptr;
        m_external_device_buffer = true;
        m_allocated              = m_allocated | DEVICE;
        return true;
    }

    /**
     * @brief Stop referencing an external device buffer without freeing it.
     */
    void detach_device_buffer()
    {
        if (!m_external_device_buffer) {
            return;
        }

        m_d_data                 = nullptr;
        m_external_device_buffer = false;
        m_allocated              = m_allocated & (~DEVICE);
    }

    /**
     * @brief Reset attribute to certain value
     * @param value value to set
     * @param location which location (device, host, or both) where attribute
     * will be set
     * @param stream in case of DEVICE, this is the stream that will be used to
     * launch the reset kernel
     */
    void reset(const T value, locationT location, cudaStream_t stream = NULL);

    /**
     * @brief Copy memory from one location to another. If target is not
     * allocated, it will be allocated first before copying the memory.
     * @param source the source location
     * @param target the destination location
     * @param stream to be used to launch the kernel
     * TODO it is better to launch a kernel that do the memcpy than relying on
     * the host API from CUDA since all these small memcpy will be enqueued in
     * the same stream and so serialized
     */
    void move(locationT source, locationT target, cudaStream_t stream = NULL);

    /**
     * @brief Release allocated memory in certain location
     * @param location where memory will be released
     */
    void release(locationT location = LOCATION_ALL);

    /**
     * @brief Deep copy from a source attribute. If source_flag and dst_flag are
     * both set to LOCATION_ALL, then we copy what is on host to host, and what
     * on device to device. If source_flag is set to HOST (or DEVICE) and
     * dst_flag is set to LOCATION_ALL, then we copy source's HOST (or
     * DEVICE) to both HOST and DEVICE.
     * @param source attribute to copy from
     * @param source_flag defines where we will copy from
     * @param dst_flag defines where we will copy to
     * @param stream used to launch kernel/memcpy
     */
    void copy_from(Attribute<T, HandleT>& source,
                   locationT              source_flag,
                   locationT              dst_flag,
                   cudaStream_t           stream = NULL);

    /**
     * @brief Accessing an attribute using a handle to the mesh element
     * @param handle input handle
     * @param attr the attribute id
     * @return const reference to the attribute
     */
    __host__ __device__ __forceinline__ T& operator()(
        const HandleT  handle,
        const uint32_t attr = 0) const
    {
        auto pl = handle.unpack();
        return this->operator()(pl.first, pl.second, attr);
    }

    /**
     * @brief Accessing the attribute as a glm vector. This is used for read
     * only since the return result is a copy.
     * @tparam N dimension of the vector
     */
    template <int N>
    __host__ __device__ __forceinline__ vec<T, N> to_glm(
        const HandleT& handle) const
    {
        assert(N <= get_num_attributes());

        const auto     pl  = handle.unpack();
        const uint32_t p   = pl.first;
        const uint16_t lid = pl.second;

        vec<T, N> ret;

#pragma unroll
        for (int i = 0; i < N; ++i) {
            ret[i] = this->operator()(p, lid, i);
        }
        return ret;
    }

    /**
     * @brief store a glm vector in this attribute. The size of glm vector
     * should match the number of attributes in this attribute
     * @tparam N dimension of the vector
     */
    template <int N>
    __host__ __device__ __forceinline__ void from_glm(const HandleT&   handle,
                                                      const vec<T, N>& in)
    {
        assert(N <= get_num_attributes());

        const auto     pl  = handle.unpack();
        const uint32_t p   = pl.first;
        const uint16_t lid = pl.second;

#pragma unroll
        for (int i = 0; i < N; ++i) {
            this->operator()(p, lid, i) = in[i];
        }
    }

    /**
     * @brief Accessing the attribute as an Eigen matrix. This is used for read
     * only since the return result is a copy.
     * @tparam N dimension of the vector
     */
    template <int N>
    __host__ __device__ __inline__ Eigen::Matrix<T, N, 1> to_eigen(
        const HandleT& handle) const
    {
        assert(N <= get_num_attributes());

        Eigen::Matrix<T, N, 1> ret;

        for (Eigen::Index i = 0; i < N; ++i) {
            ret[i] = this->operator()(handle, i);
        }
        return ret;
    }

    /**
     * @brief store an Eigen (small) vector in this attribute. The size of Eigen
     * vector should match the number of attributes in this attribute
     * @tparam N dimension of the vector
     */
    template <int N>
    __host__ __device__ __inline__ void from_eigen(
        const HandleT&                handle,
        const Eigen::Matrix<T, N, 1>& in)
    {
        assert(N <= get_num_attributes());

        for (Eigen::Index i = 0; i < N; ++i) {
            this->operator()(handle, i) = in[i];
        }
    }

    /**
     * @brief Accessing an attribute using a handle to the mesh element
     * @param handle input handle
     * @param attr the attribute id
     * @return non-const reference to the attribute
     */
    __host__ __device__ __forceinline__ T& operator()(const HandleT  handle,
                                                      const uint32_t attr = 0)
    {
        auto pl = handle.unpack();
        return this->operator()(pl.first, pl.second, attr);
    }

    /**
     * @brief Access the attribute value using patch and local index in the
     * patch. This is meant to be used by XXAttribute not directly by the user
     * @param p_id patch to be accessed
     * @param local_id the local id in the patch
     * @param attr the attribute id
     * @return const reference to the attribute
     */
    __host__ __device__ __forceinline__ T& operator()(const uint32_t p_id,
                                                      const uint16_t local_id,
                                                      const uint32_t attr) const
    {
        assert(p_id < m_max_num_patches);
        assert(attr < m_num_attributes);

        if (m_layout == SoA) {
#ifdef __CUDA_ARCH__
            assert(local_id < capacity(p_id));
            return m_d_data[attr * m_num_elements +
                            linear_index(p_id, local_id)];
#else
            assert(local_id < capacity(p_id));
            return m_h_data[attr * m_num_elements +
                            linear_index(p_id, local_id)];
#endif
        }

#ifdef __CUDA_ARCH__
        assert(local_id < capacity(p_id));
        const uint32_t offset = m_d_offsets[p_id];
        return m_d_data[offset + local_id * pitch_x() + attr * pitch_y(p_id)];
#else
        assert(local_id < size(p_id));
        const uint32_t offset = m_h_offsets[p_id];
        return m_h_data[offset + local_id * pitch_x() + attr * pitch_y(p_id)];
#endif
    }

    /**
     * @brief Access the attribute value using patch and local index in the
     * patch. This is meant to be used by XXAttribute not directly by the user
     * @param p_id patch to be accessed
     * @param local_id the local id in the patch
     * @param attr the attribute id
     * @return non-const reference to the attribute
     */
    __host__ __device__ __forceinline__ T& operator()(const uint32_t p_id,
                                                      const uint16_t local_id,
                                                      const uint32_t attr)
    {
        assert(p_id < m_max_num_patches);
        assert(attr < m_num_attributes);

        if (m_layout == SoA) {
#ifdef __CUDA_ARCH__
            assert(local_id < capacity(p_id));
            return m_d_data[attr * m_num_elements +
                            linear_index(p_id, local_id)];
#else
            assert(local_id < capacity(p_id));
            return m_h_data[attr * m_num_elements +
                            linear_index(p_id, local_id)];
#endif
        }

#ifdef __CUDA_ARCH__
        assert(local_id < capacity(p_id));
        const uint32_t offset = m_d_offsets[p_id];
        return m_d_data[offset + local_id * pitch_x() + attr * pitch_y(p_id)];
#else
        assert(local_id < size(p_id));
        const uint32_t offset = m_h_offsets[p_id];
        return m_h_data[offset + local_id * pitch_x() + attr * pitch_y(p_id)];
#endif
    }


    /**
     * @brief load the attribute into Eigen matrix using a Scalar type that
     * could be active (i.e., tracking derivatives) or passive (i.e., plain
     * floating point). The Scalar type is deduced from the handle's
     * DiffHandleT::Active.
     * @tparam VariableDim the dimension/number of components of the variable
     * @tparam DiffHandleT the type of the handle
     * @param handle the handle at which the attribute will be read
     */
    template <int VariableDim, typename DiffHandleT>
    __host__ __device__ __inline__ auto active(const DiffHandleT& handle) const
    {
        using ActiveT = typename DiffHandleT::Active;
        Eigen::Vector<ActiveT, VariableDim> ret;

        assert(VariableDim <= get_num_attributes());


        // val
        for (int j = 0; j < VariableDim; ++j) {
            if constexpr (DiffHandleT::IsActive) {
                ret[j].val() = (*this)(handle, j);
            } else {
                ret[j] = (*this)(handle, j);
            }
        }

        // init grad
        if constexpr (DiffHandleT::IsActive) {
            for (int j = 0; j < VariableDim; ++j) {
                ret[j].grad()[j] = 1;
            }
        }

        return ret;
    }


    /**
     * @brief load the attribute value at iter[index] into an Eigen vector
     * using a Scalar type that may be active (tracking derivatives) or passive
     * (plain floating point). The Scalar type is deduced from
     * DiffHandleT::Active. The gradient is initialized so that the iter[index]
     * entry is treated as an independent variable in a query of size
     * iter.size() x VariableDim.
     * @tparam VariableDim dimension/number of components of the variable
     * @tparam DiffHandleT type of the handle (deduced)
     * @tparam IteratorT type of the iterator (deduced)
     * @param handle the handle this lambda/kernel is invoked on (used to pick
     * active vs. passive scalar type)
     * @param iter iterator over neighboring elements
     * @param index position within iter whose value to load
     */
    template <int VariableDim, typename DiffHandleT, typename IteratorT>
    __host__ __device__ __inline__ auto active(const DiffHandleT& handle,
                                               const IteratorT&   iter,
                                               int                index) const
    {
        using ActiveT = typename DiffHandleT::Active;
        Eigen::Vector<ActiveT, VariableDim> ret;

        assert(index < iter.size());
        assert(VariableDim <= get_num_attributes());

        for (int j = 0; j < VariableDim; ++j) {
            if constexpr (DiffHandleT::IsActive) {
                ret[j].val() = (*this)(iter[index], j);
            } else {
                ret[j] = (*this)(iter[index], j);
            }
        }

        if constexpr (DiffHandleT::IsActive) {
            for (int j = 0; j < VariableDim; ++j) {
                ret[j].grad()[index_mapping(VariableDim, index, j)] = 1;
            }
        }

        return ret;
    }


    /**
     * @brief Loads the attribute value at "center" when index == 0, and at
     * "iter[index - 1]" when index >= 1, into an Eigen vector. The Scalar type
     * is deduced from DiffHandleT::Active. The gradient is initialized so that
     * the slot at "index" is treated as an independent variable in a query of
     * size (iter.size() + 1) x VariableDim, where slot 0 corresponds to
     * "center".
     * @tparam VariableDim dimension/number of components of the variable
     * @tparam DiffHandleT type of the differentiation handle
     * @tparam HandleT2 type of the center handle (deduced)
     * @tparam IteratorT type of the iterator (deduced)
     * @param handle the handle this lambda/kernel is invoked on (used to pick
     * active vs. passive scalar type)
     * @param center the center element handle (used when index == 0)
     * @param iter iterator over neighboring elements (used when index >= 1)
     * @param index position within [0, iter.size()] whose value to load; 0 maps
     * to "center", k maps to iter[k-1] for k >= 1
     */
    template <int VariableDim,
              typename DiffHandleT,
              typename HandleT2,
              typename IteratorT>
    __host__ __device__ __inline__ auto active(const DiffHandleT& handle,
                                               const HandleT2&    center,
                                               const IteratorT&   iter,
                                               int                index) const
    {
        using ActiveT = typename DiffHandleT::Active;
        Eigen::Vector<ActiveT, VariableDim> ret;

        assert(index < iter.size() + 1);
        assert(VariableDim <= get_num_attributes());

        for (int j = 0; j < VariableDim; ++j) {
            if constexpr (DiffHandleT::IsActive) {
                if (index == 0) {
                    ret[j].val() = (*this)(center, j);
                } else {
                    ret[j].val() = (*this)(iter[index - 1], j);
                }
            } else {
                if (index == 0) {
                    ret[j] = (*this)(center, j);
                } else {
                    ret[j] = (*this)(iter[index - 1], j);
                }
            }
        }

        if constexpr (DiffHandleT::IsActive) {
            for (int j = 0; j < VariableDim; ++j) {
                ret[j].grad()[index_mapping(VariableDim, index, j)] = 1;
            }
        }

        return ret;
    }


    /**
     * @brief Check if the attribute is empty
     */
    __host__ __device__ __forceinline__ bool is_empty() const
    {
        return m_max_num_patches == 0;
    }

   protected:
    __host__ __device__ __forceinline__ uint32_t
    linear_index(const uint32_t p_id, const uint16_t local_id) const
    {

#ifdef __CUDA_ARCH__
        return m_d_linear_id_element_prefix[p_id] + local_id;
#else
        return m_h_linear_id_element_prefix[p_id] + local_id;
#endif
    }

    /**
     * @brief allocate internal memory
     */
    void allocate(locationT location);

    /**
     * @brief allocate offset buffer (m_h_offset) and m_total_bytes
     */
    void allocate_offset();

    RXMeshStatic*    m_rxmesh;
    const PatchInfo* m_h_patches_info;
    const PatchInfo* m_d_patches_info;
    char*            m_name;
    uint32_t         m_num_attributes;
    uint32_t         m_num_elements;
    locationT        m_allocated;
    T*               m_h_data;
    T*               m_d_data;
    uint32_t*        m_h_offsets;
    uint32_t*        m_d_offsets;
    uint32_t         m_max_num_patches;
    layoutT          m_layout;
    size_t           m_total_bytes;
    uint32_t*        m_h_linear_id_element_prefix;
    uint32_t*        m_d_linear_id_element_prefix;
    // when true, m_d_data is owned by an external party and must never be
    // allocated or freed by this attribute
    bool m_external_device_buffer;

    constexpr static uint32_t m_block_size = 256;
};

template <class T>
using VertexAttribute = Attribute<T, VertexHandle>;

template <class T>
using EdgeAttribute = Attribute<T, EdgeHandle>;

template <class T>
using FaceAttribute = Attribute<T, FaceHandle>;

template <class T>
using TetAttribute = Attribute<T, TetHandle>;

/**
 * @brief Attribute container used to manage a collection of attributes by
 * RXMeshStatic
 */
class AttributeContainer
{
   public:
    AttributeContainer() : m_next_internal_attribute_id(0)
    {
    }

    virtual ~AttributeContainer()
    {
        while (!m_attr_container.empty()) {
            m_attr_container.back()->release();
            m_attr_container.back()->release_name();
            m_attr_container.pop_back();
        }
    }

    /**
     * @brief Number of attribute managed by this container
     */
    size_t size();


    /**
     * @brief get a list of name of the attributes managed by this container
     */
    std::vector<std::string> get_attribute_names() const;

    /**
     * @brief Allocate monotonically increasing internal name.
     */
    std::string make_unique_name(const std::string& prefix);

    /**
     * @brief add a new attribute to be managed by this container
     * @tparam AttrT attribute type
     * @param name unique name given to the attribute
     * @param num_attributes number of attributes per mesh element
     * @param location where the attributes will be allocated
     * @param layout memory layout in case of num_attributes > 1
     * @param rxmesh pointer to the RXMeshStatic instance
     * @return a shared pointer to the attribute
     */
    template <typename AttrT>
    std::shared_ptr<AttrT> add(const char*   name,
                               uint32_t      num_attributes,
                               locationT     location,
                               layoutT       layout,
                               RXMeshStatic* rxmesh);

    /**
     * @brief Check if an attribute exists
     * @param name of the attribute
     */
    bool does_exist(const char* name);

    /**
     * @brief remove an attribute and release its memory
     * @param name of the attribute
     */
    void remove(const char* name);

    /** @brief Remove exactly the supplied registered Attribute object. */
    void remove(const AttributeBase* attribute);

   private:
    std::vector<std::shared_ptr<AttributeBase>> m_attr_container;
    uint64_t                                    m_next_internal_attribute_id;
};

}  // namespace rxmesh
