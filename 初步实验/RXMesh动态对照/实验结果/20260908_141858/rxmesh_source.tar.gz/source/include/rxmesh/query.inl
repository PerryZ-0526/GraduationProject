namespace rxmesh {


template <uint32_t blockThreads>
__device__ __forceinline__ Query<blockThreads>::Query(const Context& context,
                                                      const uint32_t pid)
    : m_patch_info((context.m_patches_info) + pid), m_pid(pid)
{
    reset_query_storage();
}

template <uint32_t blockThreads>
__device__ __forceinline__ void Query<blockThreads>::reset_query_storage()
{
    m_shmem_before           = 0;
    m_num_src_in_patch       = 0;
    m_s_participant_bitmask  = nullptr;
    m_s_output_owned_bitmask = nullptr;
    m_s_output_offset        = nullptr;
    m_s_output_value         = nullptr;
    m_s_valence              = nullptr;
    m_op                     = Op::INVALID;
    m_s_table                = nullptr;
}

template <uint32_t blockThreads>
__device__ __forceinline__ void Query<blockThreads>::compute_vertex_valence(
    cooperative_groups::thread_block& block,
    ShmemAllocator&                   shrd_alloc)
{
    if (get_patch_id() == INVALID32) {
        return;
    }

    const uint16_t num_vertices = m_patch_info->num_vertices[0];
    const uint16_t num_edges    = m_patch_info->num_edges[0];

    m_s_valence = shrd_alloc.alloc<uint8_t>(num_vertices);

    fill_n<blockThreads>(m_s_valence, num_vertices, uint8_t(0));
    block.sync();

    for (uint16_t e = threadIdx.x; e < num_edges; e += blockThreads) {
        if (!m_patch_info->is_deleted(LocalEdgeT(e))) {
            auto [v0, v1] = m_patch_info->get_edge_vertices(e);
            atomicAdd(m_s_valence + v0, uint8_t(1));
            atomicAdd(m_s_valence + v1, uint8_t(1));
            assert(m_s_valence[v0] < 255);
            assert(m_s_valence[v1] < 255);
        }
    }
    block.sync();
}

template <uint32_t blockThreads>
__device__ __forceinline__ uint16_t
Query<blockThreads>::vertex_valence(uint16_t v) const
{
    assert(m_s_valence);
    assert(v < m_patch_info->num_vertices[0]);
    return m_s_valence[v];
}

template <uint32_t blockThreads>
__device__ __forceinline__ uint16_t
Query<blockThreads>::vertex_valence(VertexHandle vh) const
{
    assert(m_s_valence);
    assert(vh.patch_id() == m_pid);
    assert(vh.local_id() < m_patch_info->num_vertices[0]);
    return m_s_valence[vh.local_id()];
}

template <uint32_t blockThreads>
__device__ __forceinline__ void Query<blockThreads>::epilogue(
    cooperative_groups::thread_block& block,
    ShmemAllocator&                   shrd_alloc)
{
    if (get_patch_id() == INVALID32) {
        return;
    }

    // cleanup shared memory allocation
    shrd_alloc.dealloc(shrd_alloc.get_allocated_size_bytes() - m_shmem_before);
    m_num_src_in_patch       = 0;
    m_s_participant_bitmask  = nullptr;
    m_s_output_owned_bitmask = nullptr;
    m_s_output_offset        = nullptr;
    m_s_output_value         = nullptr;
    m_s_table                = nullptr;
}

template <uint32_t blockThreads>
__device__ __forceinline__ int Query<blockThreads>::get_patch_id() const
{
    return m_pid;
}

template <uint32_t blockThreads>
__device__ __forceinline__ const PatchInfo&
Query<blockThreads>::get_patch_info() const
{
    return *m_patch_info;
}

template <uint32_t blockThreads>
template <Op op, typename computeT>
__device__ __forceinline__ void Query<blockThreads>::dispatch(
    cooperative_groups::thread_block& block,
    ShmemAllocator&                   shrd_alloc,
    computeT                          compute_op,
    const bool                        oriented)
{
    // Extract the type of the first input parameters of the compute lambda
    using ComputeTraits  = detail::FunctionTraits<computeT>;
    using ComputeHandleT = typename ComputeTraits::template arg<0>::type;

    dispatch<op>(
        block,
        shrd_alloc,
        compute_op,
        [](ComputeHandleT) { return true; },
        oriented);
}

template <uint32_t blockThreads>
template <Op op, typename computeT, typename activeSetT>
__device__ __forceinline__ void Query<blockThreads>::dispatch(
    cooperative_groups::thread_block& block,
    ShmemAllocator&                   shrd_alloc,
    computeT                          compute_op,
    activeSetT                        compute_active_set,
    const bool                        oriented,
    const bool                        allow_not_owned)
{
    if (get_patch_id() == INVALID32) {
        return;
    }
    using ComputeTraits    = detail::FunctionTraits<computeT>;
    using ComputeHandleT   = typename ComputeTraits::template arg<0>::type;
    using ComputeIteratorT = typename ComputeTraits::template arg<1>::type;
    using LocalT           = typename ComputeIteratorT::LocalT;

    using ActiveSetTraits  = detail::FunctionTraits<activeSetT>;
    using ActiveSetHandleT = typename ActiveSetTraits::template arg<0>::type;
    static_assert(std::is_same_v<ActiveSetHandleT, ComputeHandleT>,
                  "First argument of compute_op lambda function should "
                  "match the first argument of active_set lambda function ");

    prologue<op>(
        block, shrd_alloc, compute_active_set, oriented, allow_not_owned);

    run_compute(block, compute_op);

    epilogue(block, shrd_alloc);
}

template <uint32_t blockThreads>
template <Op op>
__device__ __forceinline__ void Query<blockThreads>::prologue(
    cooperative_groups::thread_block& block,
    ShmemAllocator&                   shrd_alloc,
    const bool                        oriented,
    const bool                        allow_not_owned)
{
    using HandleT = typename InputHandle<op>::type;

    prologue<op>(
        block,
        shrd_alloc,
        [](HandleT) { return true; },
        oriented,
        allow_not_owned);
}

template <uint32_t blockThreads>
template <Op op, typename activeSetT>
__device__ __forceinline__ void Query<blockThreads>::prologue(
    cooperative_groups::thread_block& block,
    ShmemAllocator&                   shrd_alloc,
    activeSetT                        compute_active_set,
    const bool                        oriented,
    const bool                        allow_not_owned)
{
    if (get_patch_id() == INVALID32) {
        return;
    }

    m_op           = op;
    m_shmem_before = shrd_alloc.get_allocated_size_bytes();

    detail::query_block_dispatcher<op, blockThreads>(block,
                                                     shrd_alloc,
                                                     *m_patch_info,
                                                     compute_active_set,
                                                     oriented,
                                                     m_num_src_in_patch,
                                                     m_s_output_offset,
                                                     m_s_output_value,
                                                     m_s_participant_bitmask,
                                                     m_s_output_owned_bitmask,
                                                     m_output_lp_hashtable,
                                                     m_s_table,
                                                     allow_not_owned);
}

template <uint32_t blockThreads>
template <typename computeT>
__device__ __forceinline__ void Query<blockThreads>::run_compute(
    cooperative_groups::thread_block& block,
    computeT                          compute_op)
{
    if (get_patch_id() == INVALID32) {
        return;
    }

    using ComputeTraits    = detail::FunctionTraits<computeT>;
    using ComputeHandleT   = typename ComputeTraits::template arg<0>::type;
    using ComputeIteratorT = typename ComputeTraits::template arg<1>::type;

    for (uint16_t local_id = threadIdx.x; local_id < m_num_src_in_patch;
         local_id += blockThreads) {

        if (detail::is_set_bit(local_id, m_s_participant_bitmask)) {

            assert(m_s_output_value);

            ComputeHandleT   handle(m_pid, local_id);
            ComputeIteratorT iter = get_iterator<ComputeIteratorT>(local_id);
            compute_op(handle, iter);
        }
    }
}

template <uint32_t blockThreads>
template <typename IteratorT>
__device__ __forceinline__ IteratorT
Query<blockThreads>::get_iterator(uint16_t local_id) const
{
    const uint32_t fixed_offset = query_fixed_size(m_op);

    using LocalT = typename IteratorT::LocalT;

    if (detail::is_set_bit(local_id, m_s_participant_bitmask)) {
        return IteratorT(local_id,
                         reinterpret_cast<LocalT*>(m_s_output_value),
                         m_s_output_offset,
                         fixed_offset,
                         m_pid,
                         m_s_output_owned_bitmask,
                         m_output_lp_hashtable,
                         m_s_table,
                         m_patch_info->patch_stash,
                         query_output_shift(m_op));
    } else {
        return IteratorT(local_id, m_pid);
    }
}

}  // namespace rxmesh
