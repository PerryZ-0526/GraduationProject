#pragma once

#include <sstream>

#include "rxmesh/rxmesh_static.h"

#include "rxmesh/attribute.h"
#include "rxmesh/reduce_handle.h"

#include "rxmesh/diff/diff_query_kernel.cuh"
#include "rxmesh/diff/hessian_sparse_matrix.h"
#include "rxmesh/matrix/dense_matrix.h"


namespace rxmesh {

namespace detail {

/**
 * @brief every loss add an attribute which is where the loss write its
 * output per element. this attribute is later summed to return the total loss.
 * this attribute is owned by both ScalarTerm and AttributeContainer. Even if
 * the ScalarTerm is deleted, the AttributeContainer won't delete the
 * attribute--it only deletes it when the RXMeshStatic is deleted. Thus, here
 * we register this attribute which allows us to delete the (loss) attribute
 * when the ScalarTerm is deleted 
 */
class RegisteredAttributeOwner
{
   public:
    RegisteredAttributeOwner()                                = default;
    RegisteredAttributeOwner(const RegisteredAttributeOwner&) = delete;
    RegisteredAttributeOwner& operator=(const RegisteredAttributeOwner&) =
        delete;

    ~RegisteredAttributeOwner()
    {
        reset();
    }

    void bind(RXMeshStatic& rx, AttributeBase* attribute)
    {
        reset();
        m_rx        = &rx;
        m_attribute = attribute;
    }

    void reset()
    {
        if (m_rx != nullptr && m_attribute != nullptr) {
            m_rx->remove_attribute(m_attribute);
        }
        m_rx        = nullptr;
        m_attribute = nullptr;
    }

   private:
    RXMeshStatic*  m_rx        = nullptr;
    AttributeBase* m_attribute = nullptr;
};

}  // namespace detail

/**
 * @brief pure virtual class used as interface for all energy terms (without
 * specifying the which type of mesh elements it is specified on, number of
 * variables). This is used to store the all energies inside DiffScalarProblem
 */
template <typename T, typename OptVarHandleT>
struct ScalarTerm
{
    virtual ~ScalarTerm() = default;

    virtual void eval_active(Attribute<T, OptVarHandleT>& opt_var,
                             FaceAttribute<VertexHandle>* face_interact_vertex,
                             cudaStream_t                 stream) = 0;

    virtual void eval_active_grad_only(
        Attribute<T, OptVarHandleT>&     opt_var,
        FaceAttribute<VertexHandle>*     face_interact_vertex,
        DenseMatrix<T, Eigen::RowMajor>& gradient_output,
        cudaStream_t                     stream) = 0;

    virtual void eval_passive(Attribute<T, OptVarHandleT>& opt_var,
                              FaceAttribute<VertexHandle>* face_interact_vertex,
                              cudaStream_t                 stream) = 0;

    virtual void eval_active_matvec(
        Attribute<T, OptVarHandleT>&           opt_var,
        const DenseMatrix<T, Eigen::RowMajor>& input,
        DenseMatrix<T, Eigen::RowMajor>&       output,
        cudaStream_t                           stream) = 0;

    virtual T get_loss(cudaStream_t stream) = 0;

    virtual void get_loss_device(T* device_output, cudaStream_t stream) = 0;

    virtual locationT get_loss_allocated() const = 0;

    virtual void update_hessian(void* hess_ptr) = 0;
};

/**
 * @brief concrete class that defines energy terms for specific mesh type,
 * specific number of variable, etc. Used to define energy terms that require
 * local query operations, e.g., FV
 */
template <typename LossHandleT,
          typename OptVarHandleT,
          uint32_t blockThreads,
          Op       op,
          typename ScalarT,
          bool ProjectHess,
          int  VariableDim,
          typename LambdaT>
struct TemplatedScalarTerm
    : public ScalarTerm<typename ScalarT::PassiveType, OptVarHandleT>
{
    using T = typename ScalarT::PassiveType;

    // Scalar type that only store the 1st derivative
    // This will be the same as ScalarT if ScalarT has WithHessian=false
    using ScalarGradOnlyT = Scalar<T, ScalarT::k_, false>;


    TemplatedScalarTerm(RXMeshStatic&                        rx,
                        LambdaT                              t,
                        bool                                 oreinted,
                        DenseMatrix<T, Eigen::RowMajor>*     grad,
                        HessianSparseMatrix<T, VariableDim>* hess,
                        locationT term_loss_location = LOCATION_ALL)
        : term(t), rx(rx), grad(grad), hess(hess), oreinted(oreinted)
    {
        const std::string name = rx.make_unique_attribute_name("rx:diff:loss:");
        loss = rx.add_attribute<T, LossHandleT>(name, 1, term_loss_location);
        loss_registration.bind(rx, loss.get());

        reducer = std::make_shared<ReduceHandle<T, LossHandleT>>(*loss);

        rx.prepare_launch_box(
            {op},
            lb_active,
            (void*)detail::diff_scalar_kernel_active<blockThreads,
                                                     LossHandleT,
                                                     OptVarHandleT,
                                                     op,
                                                     ScalarT,
                                                     ProjectHess,
                                                     VariableDim,
                                                     LambdaT>,
            oreinted);

        rx.prepare_launch_box(
            {op},
            lb_passive,
            (void*)detail::diff_scalar_kernel_passive<blockThreads,
                                                      LossHandleT,
                                                      OptVarHandleT,
                                                      op,
                                                      ScalarT,
                                                      LambdaT>,
            oreinted);


        rx.prepare_launch_box(
            {op},
            lb_active_matvec,
            (void*)detail::hess_matvec_scalar_kernel<blockThreads,
                                                     LossHandleT,
                                                     OptVarHandleT,
                                                     op,
                                                     ScalarT,
                                                     ProjectHess,
                                                     VariableDim,
                                                     LambdaT>,
            oreinted);

        rx.prepare_launch_box(
            {op},
            lb_active_grad_only,
            (void*)detail::diff_scalar_kernel_active<blockThreads,
                                                     LossHandleT,
                                                     OptVarHandleT,
                                                     op,
                                                     ScalarGradOnlyT,
                                                     ProjectHess,
                                                     VariableDim,
                                                     LambdaT>,
            oreinted);
    }

    /**
     * @brief Evaluate the energy term using active/differentiable type
     */
    void eval_active(Attribute<T, OptVarHandleT>& opt_var,
                     FaceAttribute<VertexHandle>* face_interact_vertex,
                     cudaStream_t                 stream)
    {
        if (ScalarT::k_ == -1) {
            RXMESH_ERROR(
                "TemplatedTerm::eval_active() Dynamic Scalar is not supported "
                "for Hessians.");
            return;
        }

        rx.run_kernel(lb_active,
                      detail::diff_scalar_kernel_active<blockThreads,
                                                        LossHandleT,
                                                        OptVarHandleT,
                                                        op,
                                                        ScalarT,
                                                        ProjectHess,
                                                        VariableDim,
                                                        LambdaT>,
                      stream,
                      *grad,
                      *hess,
                      *loss,
                      opt_var,
                      oreinted,
                      term);
    }


    /**
     * @brief Evaluate the energy term using active/differentiable type for the
     * 1st derivative only
     */
    void eval_active_grad_only(
        Attribute<T, OptVarHandleT>&     opt_var,
        FaceAttribute<VertexHandle>*     face_interact_vertex,
        DenseMatrix<T, Eigen::RowMajor>& gradient_output,
        cudaStream_t                     stream)
    {
        rx.run_kernel(lb_active_grad_only,
                      detail::diff_scalar_kernel_active<blockThreads,
                                                        LossHandleT,
                                                        OptVarHandleT,
                                                        op,
                                                        ScalarGradOnlyT,
                                                        ProjectHess,
                                                        VariableDim,
                                                        LambdaT>,
                      stream,
                      gradient_output,
                      *hess,
                      *loss,
                      opt_var,
                      oreinted,
                      term);
    }


    /**
     * @brief Evaluate the energy term using active/differentiable type but
     * without constructing the Hessian. Instead, we do matvec with the Hessian
     */
    void eval_active_matvec(Attribute<T, OptVarHandleT>&           opt_var,
                            const DenseMatrix<T, Eigen::RowMajor>& input,
                            DenseMatrix<T, Eigen::RowMajor>&       output,
                            cudaStream_t                           stream)
    {
        if (!ScalarT::WithHessian_) {
            RXMESH_ERROR(
                "TemplatedTerm::eval_active_matvec() can not run with scalar "
                "type that does not have Hessians. Returning without "
                "evolution.");
            return;
        }

        if (ScalarT::k_ == -1) {
            RXMESH_ERROR(
                "TemplatedTerm::eval_active_matvec() Dynamic Scalar is not "
                "supported for Hessians.");
            return;
        }

        rx.run_kernel(lb_active,
                      detail::hess_matvec_scalar_kernel<blockThreads,
                                                        LossHandleT,
                                                        OptVarHandleT,
                                                        op,
                                                        ScalarT,
                                                        ProjectHess,
                                                        VariableDim,
                                                        LambdaT>,
                      stream,
                      input,
                      output,
                      opt_var,
                      oreinted,
                      term);
    }

    /**
     * @brief Evaluate the energy term using non-active/non-differentiable type
     */
    void eval_passive(Attribute<T, OptVarHandleT>& opt_var,
                      FaceAttribute<VertexHandle>* face_interact_vertex,
                      cudaStream_t                 stream)
    {
        rx.run_kernel(lb_passive,
                      detail::diff_scalar_kernel_passive<blockThreads,
                                                         LossHandleT,
                                                         OptVarHandleT,
                                                         op,
                                                         ScalarT,
                                                         LambdaT>,
                      stream,
                      *loss,
                      opt_var,
                      oreinted,
                      term);
    }

    /**
     * @brief get the current loss of the energy. Should be called evaluating
     * the term using active type
     */
    T get_loss(cudaStream_t stream = NULL)
    {
        return reducer->reduce(*loss, cub::Sum(), 0, INVALID32, stream);
    }

    void get_loss_device(T* device_output, cudaStream_t stream)
    {
        reducer->reduce_device(
            *loss, cub::Sum(), T(0), device_output, INVALID32, stream);
    }

    locationT get_loss_allocated() const
    {
        return loss == nullptr ? LOCATION_NONE : loss->get_allocated();
    }

    /**
     * @brief update the pointer to hessian stored in this class
     */
    void update_hessian(void* hess_ptr)
    {
        hess = static_cast<HessianSparseMatrix<T, VariableDim>*>(hess_ptr);
    }

    LambdaT term;

    std::shared_ptr<Attribute<T, LossHandleT>>    loss;
    detail::RegisteredAttributeOwner              loss_registration;
    std::shared_ptr<ReduceHandle<T, LossHandleT>> reducer;
    LaunchBox<blockThreads>                       lb_active;
    LaunchBox<blockThreads>                       lb_passive;
    LaunchBox<blockThreads>                       lb_active_matvec;
    LaunchBox<blockThreads>                       lb_active_grad_only;


    bool oreinted;

    RXMeshStatic&                        rx;
    DenseMatrix<T, Eigen::RowMajor>*     grad;
    HessianSparseMatrix<T, VariableDim>* hess;
};


/**
 * @brief concrete class that defines energy terms for specific mesh type,
 * specific number of variable, etc. Used to define energy terms that requires
 * pairs of mesh elements
 */
template <typename LossHandleT,
          typename OptVarHandleT,
          uint32_t blockThreads,
          typename HandleT0,
          typename HandleT1,
          typename HessMatT,
          typename ScalarT,
          bool ProjectHess,
          int  VariableDim,
          typename LambdaT>
struct TemplatedScalarTermPairs
    : public ScalarTerm<typename ScalarT::PassiveType, OptVarHandleT>
{
    using T = typename ScalarT::PassiveType;

    // Scalar type that only store the 1st derivative
    // This will be the same as ScalarT if ScalarT has WithHessian=false
    using ScalarGradOnlyT = Scalar<T, ScalarT::k_, false>;

    TemplatedScalarTermPairs(
        RXMeshStatic&                                 rx,
        LambdaT                                       t,
        DenseMatrix<T, Eigen::RowMajor>*              grad,
        HessianSparseMatrix<T, VariableDim>*          hess,
        CandidatePairs<HandleT0, HandleT1, HessMatT>& pairs,
        locationT term_loss_location = LOCATION_ALL)
        : term(t), rx(rx), grad(grad), hess(hess), pairs(pairs)
    {
        const std::string name = rx.make_unique_attribute_name("rx:diff:loss:");
        loss = rx.add_attribute<T, LossHandleT>(name, 1, term_loss_location);
        loss_registration.bind(rx, loss.get());

        reducer = std::make_shared<ReduceHandle<T, LossHandleT>>(*loss);

        if constexpr ((std::is_same_v<HandleT0, FaceHandle> &&
                       std::is_same_v<HandleT1, VertexHandle>) ||
                      (std::is_same_v<HandleT1, FaceHandle> &&
                       std::is_same_v<HandleT0, VertexHandle>)) {

            rx.prepare_launch_box(
                {Op::FV},
                lb_vf_active,
                (void*)detail::diff_scalar_kernel_active_vf_pair<blockThreads,
                                                                 ScalarT,
                                                                 VariableDim,
                                                                 ProjectHess,
                                                                 LambdaT>);

            rx.prepare_launch_box(
                {Op::FV},
                lb_vf_passive,
                (void*)detail::diff_scalar_kernel_passive_vf_pair<blockThreads,
                                                                  ScalarT,
                                                                  LambdaT>);


            rx.prepare_launch_box(
                {Op::FV},
                lb_vf_active_grad_only,
                (void*)
                    detail::diff_scalar_kernel_active_vf_pair<blockThreads,
                                                              ScalarGradOnlyT,
                                                              VariableDim,
                                                              ProjectHess,
                                                              LambdaT>);
        }
    }

    /**
     * @brief Evaluate the energy term using active/differentiable type
     */
    void eval_active(Attribute<T, OptVarHandleT>& opt_var,
                     FaceAttribute<VertexHandle>* face_interact_vertex,
                     cudaStream_t                 stream)
    {
        if (ScalarT::k_ == -1) {
            RXMESH_ERROR(
                "TemplatedTermPairs::eval_active() Dynamic Scalar is not "
                "supported for Hessians.");
            return;
        }
        int size = pairs.num_pairs();

        if (size == 0) {
            return;
        }

        if constexpr ((std::is_same_v<HandleT0, FaceHandle> &&
                       std::is_same_v<HandleT1, VertexHandle>) ||
                      (std::is_same_v<HandleT1, FaceHandle> &&
                       std::is_same_v<HandleT0, VertexHandle>)) {

            rx.run_kernel(
                lb_vf_active,
                detail::diff_scalar_kernel_active_vf_pair<blockThreads,
                                                          ScalarT,
                                                          VariableDim,
                                                          ProjectHess,
                                                          LambdaT>,
                stream,
                *grad,
                *hess,
                *loss,
                opt_var,
                *face_interact_vertex,
                term);
        } else {

            const int blocks = DIVIDE_UP(size, blockThreads);

            detail::diff_scalar_kernel_active_pair<blockThreads,
                                                   LossHandleT,
                                                   OptVarHandleT,
                                                   HandleT0,
                                                   HandleT1,
                                                   HessMatT,
                                                   ScalarT,
                                                   ProjectHess,
                                                   VariableDim,
                                                   LambdaT>
                <<<blocks, blockThreads, 0, stream>>>(
                    pairs, *grad, *hess, *loss, opt_var, term);
        }
    }


    /**
     * @brief Evaluate the energy term using active/differentiable type for the
     * 1st derivative only
     */
    void eval_active_grad_only(
        Attribute<T, OptVarHandleT>&     opt_var,
        FaceAttribute<VertexHandle>*     face_interact_vertex,
        DenseMatrix<T, Eigen::RowMajor>& gradient_output,
        cudaStream_t                     stream)
    {
        int size = pairs.num_pairs();

        if (size == 0) {
            return;
        }

        if constexpr ((std::is_same_v<HandleT0, FaceHandle> &&
                       std::is_same_v<HandleT1, VertexHandle>) ||
                      (std::is_same_v<HandleT1, FaceHandle> &&
                       std::is_same_v<HandleT0, VertexHandle>)) {

            rx.run_kernel(
                lb_vf_active_grad_only,
                detail::diff_scalar_kernel_active_vf_pair<blockThreads,
                                                          ScalarGradOnlyT,
                                                          VariableDim,
                                                          ProjectHess,
                                                          LambdaT>,
                stream,
                gradient_output,
                *hess,
                *loss,
                opt_var,
                *face_interact_vertex,
                term);
        } else {

            const int blocks = DIVIDE_UP(size, blockThreads);

            detail::diff_scalar_kernel_active_pair<blockThreads,
                                                   LossHandleT,
                                                   OptVarHandleT,
                                                   HandleT0,
                                                   HandleT1,
                                                   HessMatT,
                                                   ScalarGradOnlyT,
                                                   ProjectHess,
                                                   VariableDim,
                                                   LambdaT>
                <<<blocks, blockThreads, 0, stream>>>(
                    pairs, gradient_output, *hess, *loss, opt_var, term);
        }
    }


    /**
     * @brief Evaluate the energy term using active/differentiable type but
     * without constructing the Hessian. Instead, we do matvec with the Hessian
     */
    void eval_active_matvec(Attribute<T, OptVarHandleT>&           opt_var,
                            const DenseMatrix<T, Eigen::RowMajor>& input,
                            DenseMatrix<T, Eigen::RowMajor>&       output,
                            cudaStream_t                           stream)
    {
        if (!ScalarT::WithHessian_) {
            RXMESH_ERROR(
                "TemplatedTermPairs::eval_active_matvec() can not run with "
                "scalar type that does not have Hessians. Returning without "
                "evolution.");
            return;
        }

        if (ScalarT::k_ == -1) {
            RXMESH_ERROR(
                "TemplatedTermPairs::eval_active_matvec() Dynamic Scalar is "
                "not supported for Hessians.");
            return;
        }
        int size = pairs.num_pairs();

        if (size == 0) {
            return;
        }

        // TODO
        RXMESH_ERROR(
            "TemplatedTermPairs::eval_active_matvec() Not implemented.");
    }

    /**
     * @brief Evaluate the energy term using non-active/non-differentiable type
     */
    void eval_passive(Attribute<T, OptVarHandleT>& opt_var,
                      FaceAttribute<VertexHandle>* face_interact_vertex,
                      cudaStream_t                 stream)
    {
        if constexpr ((std::is_same_v<HandleT0, FaceHandle> &&
                       std::is_same_v<HandleT1, VertexHandle>) ||
                      (std::is_same_v<HandleT1, FaceHandle> &&
                       std::is_same_v<HandleT0, VertexHandle>)) {

            rx.run_kernel(
                lb_vf_passive,
                detail::diff_scalar_kernel_passive_vf_pair<blockThreads,
                                                           ScalarT,
                                                           LambdaT>,
                stream,
                *loss,
                opt_var,
                *face_interact_vertex,
                term);


        } else {
            int size = pairs.num_pairs();

            if (size == 0) {
                return;
            }

            const int blocks = DIVIDE_UP(size, blockThreads);

            detail::diff_scalar_kernel_passive_pair<blockThreads,
                                                    LossHandleT,
                                                    OptVarHandleT,
                                                    HandleT0,
                                                    HandleT1,
                                                    HessMatT,
                                                    ScalarT,
                                                    LambdaT>
                <<<blocks, blockThreads, 0, stream>>>(
                    pairs, *loss, opt_var, term);
        }
    }

    /**
     * @brief get the current loss of the energy. Should be called evaluating
     * the term using active type
     */
    T get_loss(cudaStream_t stream = NULL)
    {
        return reducer->reduce(*loss, cub::Sum(), 0, INVALID32, stream);
    }

    void get_loss_device(T* device_output, cudaStream_t stream)
    {
        reducer->reduce_device(
            *loss, cub::Sum(), T(0), device_output, INVALID32, stream);
    }

    locationT get_loss_allocated() const
    {
        return loss == nullptr ? LOCATION_NONE : loss->get_allocated();
    }

    /**
     * @brief update the pointer to hessian stored in this class
     */
    void update_hessian(void* hess_ptr)
    {
        hess = static_cast<HessianSparseMatrix<T, VariableDim>*>(hess_ptr);
    }

    LambdaT term;

    RXMeshStatic&                                 rx;
    std::shared_ptr<Attribute<T, LossHandleT>>    loss;
    detail::RegisteredAttributeOwner              loss_registration;
    std::shared_ptr<ReduceHandle<T, LossHandleT>> reducer;

    DenseMatrix<T, Eigen::RowMajor>*              grad;
    HessianSparseMatrix<T, VariableDim>*          hess;
    CandidatePairs<HandleT0, HandleT1, HessMatT>& pairs;

    LaunchBox<blockThreads> lb_vf_passive;
    LaunchBox<blockThreads> lb_vf_active;
    LaunchBox<blockThreads> lb_vf_active_grad_only;
};
}  // namespace rxmesh
