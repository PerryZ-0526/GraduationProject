#pragma once
#include <cub/cub.cuh>

#include "rxmesh/attribute.h"
#include "rxmesh/kernels/reduce.cuh"

#include "rxmesh/arg_ops.h"

#include "rxmesh/rxmesh.h"

namespace rxmesh {

/**
 * @brief This class is used to compute different reduction operations on
 * Attribute. To create a new ReduceHandle, use create_reduce_handle()
 * from Attribute
 * @tparam T The type of the attribute
 * TODO allows for async dot(), norm2(), arg_max(), arg_min() similar to
 * reduce_device()
 */
template <typename T, typename HandleT>
class ReduceHandle
{

   public:
    using HandleType = HandleT;
    using Type       = T;
    using KeyValue   = KeyValuePair<HandleT, T>;

    ReduceHandle()                    = default;
    ReduceHandle(const ReduceHandle&) = default;

    /**
     * @brief Constructor which allocates internal memory used in all reduce
     * operations
     * @param attr one of Attribute used for subsequent reduction
     * operations
     */
    ReduceHandle(const Attribute<T, HandleT>& attr)
        : ReduceHandle(attr.m_max_num_patches)
    {
    }

    /**
     * @brief Constructor which allocates internal memory used in all reduce
     * operations
     * @param rx could be instance of RXMeshStatic or RXMeshDynamic
     */
    ReduceHandle(const RXMesh& rx) : ReduceHandle(rx.get_num_patches())
    {
    }

    /**
     * @brief Constructor which allocates internal memory used in all reduce
     * operations
     * @param num_patches is the number of patches in the mesh
     */
    ReduceHandle(uint32_t num_patches);

    ~ReduceHandle();

    /**
     * @brief compute dot product between two input attributes and return the
     * output on the host
     * @param attr1 first input attribute
     * @param attr2 second input attribute
     * @param attribute_id specific attribute ID to compute its dot product.
     * Default is INVALID32 which compute dot product for all attributes
     * @param stream stream to run the computation on
     * @return the output of dot product on the host
     */
    T dot(const Attribute<T, HandleT>& attr1,
          const Attribute<T, HandleT>& attr2,
          uint32_t                     attribute_id = INVALID32,
          cudaStream_t                 stream       = NULL);

    /**
     * @brief compute L2 norm between two input attributes and return the output
     * on the host
     * @param attr input attribute
     * @param attribute_id specific attribute ID to compute its norm2. Default
     * is INVALID32 which compute norm2 for all attributes
     * @param stream stream to run the computation on
     * @return the output of L2 norm on the host
     */
    T norm2(const Attribute<T, HandleT>& attr,
            uint32_t                     attribute_id = INVALID32,
            cudaStream_t                 stream       = NULL);

    /**
     * @brief
     * @param attr
     * @param attribute_id
     * @param stream
     * @return
     */
    KeyValue arg_max(const Attribute<T, HandleT>& attr,
                     uint32_t                     attribute_id = INVALID32,
                     cudaStream_t                 stream       = NULL);

    /**
     * @brief
     * @param attr
     * @param attribute_id
     * @param stream
     * @return
     */
    KeyValue arg_min(const Attribute<T, HandleT>& attr,
                     uint32_t                     attribute_id = INVALID32,
                     cudaStream_t                 stream       = NULL);


    /**
     * @brief perform generic reduction operations on an input attribute
     * @tparam ReductionOp type of the binary reduction functor having member T
     * operator()(const T &a, const T &b)
     * @param attr input attribute
     * @param reduction_op the binary reduction functor. It is possible to use
     * CUB built-in reduction functor like cub::Max(), cub::Sum(). An example of
     * user-defined:
     *
     * struct CustomMin
     * {
     *     template <typename T>
     *     __device__ __forceinline__ T operator()(const T& a, const T& b) const
     *     {
     *         return (b < a) ? b : a;
     *     }
     * };
     * Read more about reduction from CUB doc
     * https://nvlabs.github.io/cub/structcub_1_1_device_reduce.html
     * @param init initial value for reduction. This should be the "neutral"
     * value for the reduction operations e.g., 0 for sum, 1 for multiplication,
     * 0 for max on uint32_t
     * @param device_output where the output of the reduction will be stored
     * @param attribute_id specific attribute ID to compute its reduction.
     * Default is INVALID32 which compute reduction for all attributes
     * @param stream stream to run the computation on
     * @return the reduced output on the host
     */
    template <typename ReductionOp>
    void reduce_device(const Attribute<T, HandleT>& attr,
                       ReductionOp                  reduction_op,
                       T                            init,
                       T*                           device_output,
                       uint32_t                     attribute_id = INVALID32,
                       cudaStream_t                 stream       = NULL)
    {
        if (device_output == nullptr) {
            RXMESH_ERROR(
                "ReduceHandle::reduce_device() received a null output "
                "pointer.");
            return;
        }

        if (m_max_num_patches == 0) {
            CUDA_ERROR(cudaMemcpyAsync(device_output,
                                       &init,
                                       sizeof(T),
                                       cudaMemcpyHostToDevice,
                                       stream));
            return;
        }

        if ((attr.get_allocated() & DEVICE) != DEVICE) {
            RXMESH_ERROR(
                "ReduceHandle::reduce_device() input attribute must be "
                "allocated on the device.");
            return;
        }

        detail::generic_reduce<T, attr.m_block_size>
            <<<m_max_num_patches, attr.m_block_size, 0, stream>>>(
                attr,
                m_max_num_patches,
                attr.get_num_attributes(),
                m_d_reduce_1st_stage,
                reduction_op,
                init,
                attribute_id);

        cub::DeviceReduce::Reduce(m_d_reduce_temp_storage,
                                  m_reduce_temp_storage_bytes,
                                  m_d_reduce_1st_stage,
                                  device_output,
                                  m_max_num_patches,
                                  reduction_op,
                                  init,
                                  stream);
    }

    /**
     * @brief Same as reduce_device but the results are returned on the host
     * as a scalar value
     */
    template <typename ReductionOp>
    T reduce(const Attribute<T, HandleT>& attr,
             ReductionOp                  reduction_op,
             T                            init,
             uint32_t                     attribute_id = INVALID32,
             cudaStream_t                 stream       = NULL)
    {
        T host_output = init;
        if (m_max_num_patches != 0 &&
            (attr.get_allocated() & DEVICE) != DEVICE) {
            RXMESH_ERROR(
                "ReduceHandle::reduce() input attribute must be allocated on "
                "the device.");
            return host_output;
        }
        reduce_device(attr,
                      reduction_op,
                      init,
                      m_d_reduce_2nd_stage,
                      attribute_id,
                      stream);
        CUDA_ERROR(cudaMemcpyAsync(&host_output,
                                   m_d_reduce_2nd_stage,
                                   sizeof(T),
                                   cudaMemcpyDeviceToHost,
                                   stream));
        CUDA_ERROR(cudaStreamSynchronize(stream));
        return host_output;
    }

   private:
    template <typename U, typename ReductionOp>
    U reduce_2nd_stage(cudaStream_t stream, ReductionOp reduction_op, U init)
    {
        U h_output;


        cub::DeviceReduce::Reduce(m_d_reduce_temp_storage,
                                  m_reduce_temp_storage_bytes,
                                  reinterpret_cast<U*>(m_d_reduce_1st_stage),
                                  reinterpret_cast<U*>(m_d_reduce_2nd_stage),
                                  m_max_num_patches,
                                  reduction_op,
                                  init,
                                  stream);

        CUDA_ERROR(cudaMemcpyAsync(&h_output,
                                   m_d_reduce_2nd_stage,
                                   sizeof(U),
                                   cudaMemcpyDeviceToHost,
                                   stream));
        CUDA_ERROR(cudaStreamSynchronize(stream));

        return h_output;
    }

    size_t   m_reduce_temp_storage_bytes;
    T*       m_d_reduce_1st_stage;
    T*       m_d_reduce_2nd_stage;
    void*    m_d_reduce_temp_storage;
    uint32_t m_max_num_patches;
};

template <class T>
using VertexReduceHandle = ReduceHandle<T, VertexHandle>;

template <class T>
using EdgeReduceHandle = ReduceHandle<T, EdgeHandle>;

template <class T>
using FaceReduceHandle = ReduceHandle<T, FaceHandle>;

template <class T>
using TetReduceHandle = ReduceHandle<T, TetHandle>;

}  // namespace rxmesh
