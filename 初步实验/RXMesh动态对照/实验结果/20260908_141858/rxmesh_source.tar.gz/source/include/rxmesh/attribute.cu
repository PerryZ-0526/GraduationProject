#include <algorithm>
#include <cstring>
#include <memory>
#include <vector>

#include "rxmesh/rxmesh_static.h"

#include "rxmesh/attribute.h"
#include "rxmesh/handle.h"
#include "rxmesh/matrix/dense_matrix.h"
#include "rxmesh/types.h"

#include <glm/gtx/norm.hpp>

#include "thrust/complex.h"

namespace rxmesh {

namespace detail {
template <typename T, typename HandleT>
__global__ void memset_attribute(T* data, const T value, const size_t size)
{
    const size_t tid = threadIdx.x + blockIdx.x * blockDim.x;
    if (tid < size) {
        data[tid] = value;
    }
}
}  // namespace detail

template <class T, typename HandleT>
__host__ Attribute<T, HandleT>::Attribute(const char*    name,
                                          const uint32_t num_attributes,
                                          locationT      location,
                                          const layoutT  layout,
                                          RXMeshStatic*  rxmesh)
    : AttributeBase(),
      m_rxmesh(rxmesh),
      m_h_patches_info(rxmesh->m_h_patches_info),
      m_d_patches_info(rxmesh->m_d_patches_info),
      m_name(nullptr),
      m_num_attributes(num_attributes),
      m_num_elements(0),
      m_allocated(LOCATION_NONE),
      m_h_data(nullptr),
      m_d_data(nullptr),
      m_h_offsets(nullptr),
      m_d_offsets(nullptr),
      m_max_num_patches(rxmesh->get_max_num_patches()),
      m_layout(layout),
      m_total_bytes(0),
      m_h_linear_id_element_prefix(rxmesh->get_element_prefix<HandleT>(HOST)),
      m_d_linear_id_element_prefix(rxmesh->get_element_prefix<HandleT>(DEVICE)),
      m_external_device_buffer(false)

{
    if (m_layout == SoA && !m_rxmesh->supports_global_soa_attribute_layout()) {
        RXMESH_WARN(
            "Attribute '{}' requested true SoA on a mesh that does not support "
            "global SoA attributes. Falling back to AoSoA.",
            name == nullptr ? "" : name);
        m_layout = AoSoA;
    }

    if constexpr (std::is_same_v<HandleT, VertexHandle>) {
        m_num_elements = rxmesh->get_num_vertices();
    }
    if constexpr (std::is_same_v<HandleT, EdgeHandle>) {
        m_num_elements = rxmesh->get_num_edges();
    }
    if constexpr (std::is_same_v<HandleT, FaceHandle>) {
        m_num_elements = rxmesh->get_num_faces();
    }
    if constexpr (std::is_same_v<HandleT, TetHandle>) {
        m_num_elements = rxmesh->get_num_tets();
    }

    if (name != nullptr) {
        this->m_name = (char*)malloc(sizeof(char) * (strlen(name) + 1));
        strcpy(this->m_name, name);
    }

    if (m_rxmesh->get_num_patches() == 0) {
        return;
    }

    allocate(location);
}

template <class T, typename HandleT>
T& Attribute<T, HandleT>::operator()(size_t i, size_t j)
{
    if (m_layout == SoA) {
        assert(i < m_num_elements);
        assert(j < m_num_attributes);
        return m_h_data[j * m_num_elements + i];
    }

    if constexpr (std::is_same_v<HandleT, VertexHandle>) {
        return this->operator()(m_rxmesh->map_to_local_vertex(i), j);
    }
    if constexpr (std::is_same_v<HandleT, EdgeHandle>) {
        return this->operator()(m_rxmesh->map_to_local_edge(i), j);
    }
    if constexpr (std::is_same_v<HandleT, FaceHandle>) {
        return this->operator()(m_rxmesh->map_to_local_face(i), j);
    }
    if constexpr (std::is_same_v<HandleT, TetHandle>) {
        return this->operator()(m_rxmesh->map_to_local_tet(i), j);
    }
}

template <class T, typename HandleT>
T& Attribute<T, HandleT>::operator()(size_t i, size_t j) const
{
    if (m_layout == SoA) {
        assert(i < m_num_elements);
        assert(j < m_num_attributes);
        return m_h_data[j * m_num_elements + i];
    }

    if constexpr (std::is_same_v<HandleT, VertexHandle>) {
        return this->operator()(m_rxmesh->map_to_local_vertex(i), j);
    }
    if constexpr (std::is_same_v<HandleT, EdgeHandle>) {
        return this->operator()(m_rxmesh->map_to_local_edge(i), j);
    }
    if constexpr (std::is_same_v<HandleT, FaceHandle>) {
        return this->operator()(m_rxmesh->map_to_local_face(i), j);
    }
    if constexpr (std::is_same_v<HandleT, TetHandle>) {
        return this->operator()(m_rxmesh->map_to_local_tet(i), j);
    }
}

template <class T, typename HandleT>
size_t Attribute<T, HandleT>::rows() const
{
    return size();
}

template <class T, typename HandleT>
size_t Attribute<T, HandleT>::cols() const
{
    return this->get_num_attributes();
}

template <class T, typename HandleT>
uint32_t Attribute<T, HandleT>::size() const
{
    if (m_layout == SoA) {
        return m_num_elements;
    }

    if constexpr (std::is_same_v<HandleT, VertexHandle>) {
        return m_rxmesh->get_num_vertices();
    }

    if constexpr (std::is_same_v<HandleT, EdgeHandle>) {
        return m_rxmesh->get_num_edges();
    }

    if constexpr (std::is_same_v<HandleT, FaceHandle>) {
        return m_rxmesh->get_num_faces();
    }

    if constexpr (std::is_same_v<HandleT, TetHandle>) {
        return m_rxmesh->get_num_tets();
    }

    return m_num_elements;
}

template <class T, typename HandleT>
size_t Attribute<T, HandleT>::get_total_bytes() const
{
    return m_total_bytes;
}

template <class T, typename HandleT>
template <int Order>
std::shared_ptr<DenseMatrix<T, Order>> Attribute<T, HandleT>::to_matrix() const
{
    std::shared_ptr<DenseMatrix<T, Order>> mat =
        std::make_shared<DenseMatrix<T, Order>>(
            *m_rxmesh, rows(), cols(), LOCATION_ALL);

    if constexpr (std::is_same_v<HandleT, VertexHandle>) {
        m_rxmesh->for_each_vertex(HOST, [&](const VertexHandle vh) {
            for (uint32_t j = 0; j < cols(); ++j) {
                (*mat)(vh, j) = this->operator()(vh, j);
            }
        });
    }

    if constexpr (std::is_same_v<HandleT, EdgeHandle>) {
        m_rxmesh->for_each_edge(HOST, [&](const EdgeHandle eh) {
            for (uint32_t j = 0; j < cols(); ++j) {
                (*mat)(eh, j) = this->operator()(eh, j);
            }
        });
    }

    if constexpr (std::is_same_v<HandleT, FaceHandle>) {
        m_rxmesh->for_each_face(HOST, [&](const FaceHandle fh) {
            for (uint32_t j = 0; j < cols(); ++j) {
                (*mat)(fh, j) = this->operator()(fh, j);
            }
        });
    }

    if constexpr (std::is_same_v<HandleT, TetHandle>) {
        m_rxmesh->for_each_tet(HOST, [&](const TetHandle th) {
            for (uint32_t j = 0; j < cols(); ++j) {
                (*mat)(th, j) = this->operator()(th, j);
            }
        });
    }

    mat->move(HOST, DEVICE);

    return mat;
}

template <class T, typename HandleT>
template <int Order>
void Attribute<T, HandleT>::from_matrix(DenseMatrix<T, Order>* mat)
{
    assert(mat->rows() == rows());
    assert(mat->cols() == cols());

    if constexpr (std::is_same_v<HandleT, VertexHandle>) {
        m_rxmesh->for_each_vertex(HOST, [&](const VertexHandle vh) {
            for (uint32_t j = 0; j < cols(); ++j) {
                this->operator()(vh, j) = (*mat)(vh, j);
            }
        });
    }

    if constexpr (std::is_same_v<HandleT, EdgeHandle>) {
        m_rxmesh->for_each_edge(HOST, [&](const EdgeHandle eh) {
            for (uint32_t j = 0; j < cols(); ++j) {
                this->operator()(eh, j) = (*mat)(eh, j);
            }
        });
    }

    if constexpr (std::is_same_v<HandleT, FaceHandle>) {
        m_rxmesh->for_each_face(HOST, [&](const FaceHandle fh) {
            for (uint32_t j = 0; j < cols(); ++j) {
                this->operator()(fh, j) = (*mat)(fh, j);
            }
        });
    }

    if constexpr (std::is_same_v<HandleT, TetHandle>) {
        m_rxmesh->for_each_tet(HOST, [&](const TetHandle th) {
            for (uint32_t j = 0; j < cols(); ++j) {
                this->operator()(th, j) = (*mat)(th, j);
            }
        });
    }
}


template <class T, typename HandleT>
const char* Attribute<T, HandleT>::get_name() const
{
    return m_name;
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::release_name()
{
    if (m_name != nullptr) {
        free(m_name);
        m_name = nullptr;
    }
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::reset(const T      value,
                                  locationT    location,
                                  cudaStream_t stream)
{
    if (((location & DEVICE) == DEVICE) && is_device_allocated()) {
        const int    threads = 256;
        const size_t count   = storage_size();
        if (count > 0) {
            detail::memset_attribute<T, HandleT>
                <<<DIVIDE_UP(count, threads), threads, 0, stream>>>(
                    m_d_data, value, count);
        }
    }

    if (((location & HOST) == HOST) && is_host_allocated()) {
        std::fill_n(m_h_data, storage_size(), value);
    }
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::move(locationT    source,
                                 locationT    target,
                                 cudaStream_t stream)
{
    if (source == target) {
        RXMESH_WARN(
            "Attribute::move() source ({}) and target ({}) "
            "are the same.",
            location_to_string(source),
            location_to_string(target));
        return;
    }

    if (m_external_device_buffer && (target & DEVICE) == DEVICE) {
        RXMESH_ERROR(
            "Attribute::move() cannot overwrite an attached external device "
            "buffer. Detach it first.");
        return;
    }

    if ((source == HOST || source == DEVICE) &&
        ((source & m_allocated) != source)) {
        RXMESH_ERROR(
            "Attribute::move() moving source is not valid"
            " because it was not allocated on source i.e., {}",
            location_to_string(source));
    }

    if (((target & HOST) == HOST || (target & DEVICE) == DEVICE) &&
        ((target & m_allocated) != target)) {
        RXMESH_WARN("Attribute::move() allocating target before moving to {}",
                    location_to_string(target));
        allocate(target);
    }

    if (m_rxmesh->get_num_patches() == 0) {
        return;
    }

    if (source == HOST && target == DEVICE) {
        CUDA_ERROR(cudaMemcpyAsync(m_d_data,
                                   m_h_data,
                                   get_total_bytes(),
                                   cudaMemcpyHostToDevice,
                                   stream));
    } else if (source == DEVICE && target == HOST) {
        CUDA_ERROR(cudaMemcpyAsync(m_h_data,
                                   m_d_data,
                                   get_total_bytes(),
                                   cudaMemcpyDeviceToHost,
                                   stream));
    }
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::release(locationT location)
{
    if (((location & HOST) == HOST) && is_host_allocated()) {
        free(m_h_data);
        m_h_data = nullptr;
        free(m_h_offsets);
        m_h_offsets = nullptr;
        m_allocated = m_allocated & (~HOST);
    }

    if ((location & DEVICE) == DEVICE) {
        if (m_external_device_buffer) {
            // Borrowed storage is detached, never freed by RXMesh.
            m_d_data = nullptr;
        } else if (is_device_allocated()) {
            GPU_FREE(m_d_data);
        }
        GPU_FREE(m_d_offsets);
        m_external_device_buffer = false;
        m_allocated              = m_allocated & (~DEVICE);
    }
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::copy_from(Attribute<T, HandleT>& source,
                                      locationT              source_flag,
                                      locationT              dst_flag,
                                      cudaStream_t           stream)
{
    if (source.m_layout != m_layout) {
        RXMESH_ERROR(
            "Attribute::copy_from() does not support copy from "
            "source of different layout!");
    }

    if ((source_flag & LOCATION_ALL) == LOCATION_ALL &&
        (dst_flag & LOCATION_ALL) != LOCATION_ALL) {
        RXMESH_ERROR("Attribute::copy_from() Invalid configuration!");
        return;
    }

    if (m_num_attributes != source.get_num_attributes()) {
        RXMESH_ERROR(
            "Attribute::copy_from() number of attributes is "
            "different!");
        return;
    }

    if (this->is_empty() || m_rxmesh->get_num_patches() == 0) {
        return;
    }

    if ((source_flag & HOST) == HOST && (dst_flag & HOST) == HOST) {
        if ((source.m_allocated & HOST) != HOST) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because it was not allocated on host");
            return;
        }
        if ((m_allocated & HOST) != HOST) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because location (this) was not allocated on host");
            return;
        }

        std::memcpy(m_h_data, source.m_h_data, get_total_bytes());
    }

    if ((source_flag & DEVICE) == DEVICE && (dst_flag & DEVICE) == DEVICE) {
        if ((source.m_allocated & DEVICE) != DEVICE) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because it was not allocated on device");
            return;
        }
        if ((m_allocated & DEVICE) != DEVICE) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because location (this) was not allocated on device");
            return;
        }

        CUDA_ERROR(cudaMemcpyAsync(m_d_data,
                                   source.m_d_data,
                                   get_total_bytes(),
                                   cudaMemcpyDeviceToDevice,
                                   stream));
    }

    if ((source_flag & DEVICE) == DEVICE && (dst_flag & HOST) == HOST) {
        if ((source.m_allocated & DEVICE) != DEVICE) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because it was not allocated on host");
            return;
        }
        if ((m_allocated & HOST) != HOST) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because location (this) was not allocated on device");
            return;
        }

        CUDA_ERROR(cudaMemcpyAsync(m_h_data,
                                   source.m_d_data,
                                   get_total_bytes(),
                                   cudaMemcpyDeviceToHost,
                                   stream));
    }

    if ((source_flag & HOST) == HOST && (dst_flag & DEVICE) == DEVICE) {
        if ((source.m_allocated & HOST) != HOST) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because it was not allocated on device");
            return;
        }
        if ((m_allocated & DEVICE) != DEVICE) {
            RXMESH_ERROR(
                "Attribute::copy_from() copying source is not valid"
                " because location (this) was not allocated on host");
            return;
        }

        CUDA_ERROR(cudaMemcpyAsync(m_d_data,
                                   source.m_h_data,
                                   get_total_bytes(),
                                   cudaMemcpyHostToDevice,
                                   stream));
    }
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::allocate(locationT location)
{
    if (((location & DEVICE) == DEVICE) && m_external_device_buffer) {
        RXMESH_ERROR(
            "Attribute::allocate() cannot replace an attached external "
            "device buffer. Detach it first.");
        return;
    }

    if (m_max_num_patches != 0) {
        if ((location & HOST) == HOST) {
            release(HOST);

            // alloc offset buffer
            allocate_offset();

            // alloc data
            m_h_data = static_cast<T*>(malloc(get_total_bytes()));

            m_allocated = m_allocated | HOST;
        }

        if ((location & DEVICE) == DEVICE) {
            release(DEVICE);

            allocate_offset();

            // alloc data
            CUDA_ERROR(cudaMalloc((void**)&(m_d_data), get_total_bytes()));

            if (m_layout != SoA) {
                // alloc and move offset buffer
                CUDA_ERROR(
                    cudaMalloc((void**)&(m_d_offsets),
                               sizeof(uint32_t) * (m_max_num_patches + 1)));
                CUDA_ERROR(
                    cudaMemcpy(m_d_offsets,
                               m_h_offsets,
                               sizeof(uint32_t) * (m_max_num_patches + 1),
                               cudaMemcpyHostToDevice));
            }

            m_allocated = m_allocated | DEVICE;
        }
    }
}

template <class T, typename HandleT>
void Attribute<T, HandleT>::allocate_offset()
{
    if (m_layout == SoA) {
        m_total_bytes = sizeof(T) * m_num_elements * m_num_attributes;
        return;
    }

    if (!m_h_offsets) {
        m_h_offsets = static_cast<uint32_t*>(
            malloc(sizeof(uint32_t) * (m_max_num_patches + 1)));
        m_h_offsets[0] = 0;
        for (uint32_t p = 0; p < m_max_num_patches; ++p) {
            m_h_offsets[p + 1] =
                m_h_offsets[p] + capacity(p) * m_num_attributes;
        }
        m_total_bytes = sizeof(T) * m_h_offsets[m_max_num_patches];
    }
}

size_t AttributeContainer::size()
{
    return m_attr_container.size();
}

std::vector<std::string> AttributeContainer::get_attribute_names() const
{
    std::vector<std::string> names;
    for (size_t i = 0; i < m_attr_container.size(); ++i) {
        names.push_back(m_attr_container[i]->get_name());
    }
    return names;
}

std::string AttributeContainer::make_unique_name(const std::string& prefix)
{
    std::string candidate;
    do {
        candidate = prefix + std::to_string(m_next_internal_attribute_id++);
    } while (does_exist(candidate.c_str()));
    return candidate;
}

template <typename AttrT>
std::shared_ptr<AttrT> AttributeContainer::add(const char*   name,
                                               uint32_t      num_attributes,
                                               locationT     location,
                                               layoutT       layout,
                                               RXMeshStatic* rxmesh)
{
    if (does_exist(name)) {
        RXMESH_WARN(
            "AttributeContainer::add() adding an attribute with "
            "name {} already exists!",
            std::string(name));
    }

    auto new_attr =
        std::make_shared<AttrT>(name, num_attributes, location, layout, rxmesh);
    m_attr_container.push_back(
        std::dynamic_pointer_cast<AttributeBase>(new_attr));

    return new_attr;
}

bool AttributeContainer::does_exist(const char* name)
{
    for (size_t i = 0; i < m_attr_container.size(); ++i) {
        if (!strcmp(m_attr_container[i]->get_name(), name)) {
            return true;
        }
    }
    return false;
}

void AttributeContainer::remove(const char* name)
{
    for (auto it = m_attr_container.begin(); it != m_attr_container.end();
         ++it) {

        if (!strcmp((*it)->get_name(), name)) {
            remove(it->get());
            return;
        }
    }
}

void AttributeContainer::remove(const AttributeBase* attribute)
{
    for (auto it = m_attr_container.begin(); it != m_attr_container.end();
         ++it) {
        if (it->get() == attribute) {
            (*it)->release(LOCATION_ALL);
            (*it)->release_name();
            m_attr_container.erase(it);
            return;
        }
    }
}


// Explicit instantiations

#define RXMESH_ATTRIBUTE_INST(T, HandleT) template class Attribute<T, HandleT>;

#define RXMESH_ATTRIBUTE_INST_ALL_HANDLES(T) \
    RXMESH_ATTRIBUTE_INST(T, VertexHandle)   \
    RXMESH_ATTRIBUTE_INST(T, EdgeHandle)     \
    RXMESH_ATTRIBUTE_INST(T, FaceHandle)     \
    RXMESH_ATTRIBUTE_INST(T, TetHandle)

#define RXMESH_ATTR_CONTAINER_ADD_INST(AttrT)                       \
    template std::shared_ptr<AttrT> AttributeContainer::add<AttrT>( \
        const char*, uint32_t, locationT, layoutT, RXMeshStatic*);

#define RXMESH_ATTR_CONTAINER_ADD_INST_ALL_HANDLES(T)  \
    RXMESH_ATTR_CONTAINER_ADD_INST(VertexAttribute<T>) \
    RXMESH_ATTR_CONTAINER_ADD_INST(EdgeAttribute<T>)   \
    RXMESH_ATTR_CONTAINER_ADD_INST(FaceAttribute<T>)   \
    RXMESH_ATTR_CONTAINER_ADD_INST(TetAttribute<T>)

#define RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(T) \
    RXMESH_ATTRIBUTE_INST_ALL_HANDLES(T)                   \
    RXMESH_ATTR_CONTAINER_ADD_INST_ALL_HANDLES(T)

RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(Eigen::Matrix3f)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(Eigen::Matrix2f)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(Eigen::Matrix3d)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(Eigen::Matrix2d)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(thrust::complex<float>)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(thrust::complex<double>)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(bool)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(unsigned short)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(char)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(int8_t)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(uint8_t)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(float)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(double)
// RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(int)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(uint32_t)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(int32_t)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(uint64_t)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(int64_t)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(VertexHandle)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(EdgeHandle)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(FaceHandle)
RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES(TetHandle)

#undef RXMESH_ATTRIBUTE_AND_CONTAINER_INST_ALL_HANDLES
#undef RXMESH_ATTR_CONTAINER_ADD_INST_ALL_HANDLES
#undef RXMESH_ATTR_CONTAINER_ADD_INST
#undef RXMESH_ATTRIBUTE_INST_ALL_HANDLES
#undef RXMESH_ATTRIBUTE_INST

#define RXMESH_ATTR_TM_INST(T, H)                                      \
    template std::shared_ptr<DenseMatrix<T, Eigen::ColMajor>>          \
    Attribute<T, H>::to_matrix<Eigen::ColMajor>() const;               \
    template std::shared_ptr<DenseMatrix<T, Eigen::RowMajor>>          \
                  Attribute<T, H>::to_matrix<Eigen::RowMajor>() const; \
    template void Attribute<T, H>::from_matrix<Eigen::ColMajor>(       \
        DenseMatrix<T, Eigen::ColMajor>*);                             \
    template void Attribute<T, H>::from_matrix<Eigen::RowMajor>(       \
        DenseMatrix<T, Eigen::RowMajor>*);

#define RXMESH_ATTR_TM_INST_ALL(T)       \
    RXMESH_ATTR_TM_INST(T, VertexHandle) \
    RXMESH_ATTR_TM_INST(T, EdgeHandle)   \
    RXMESH_ATTR_TM_INST(T, FaceHandle)   \
    RXMESH_ATTR_TM_INST(T, TetHandle)

RXMESH_ATTR_TM_INST_ALL(float)
RXMESH_ATTR_TM_INST_ALL(double)
RXMESH_ATTR_TM_INST_ALL(int)
RXMESH_ATTR_TM_INST_ALL(uint32_t)
RXMESH_ATTR_TM_INST_ALL(char)

#undef RXMESH_ATTR_TM_INST_ALL
#undef RXMESH_ATTR_TM_INST

#define RXMESH_ATTR_GLM_EIGEN_INST(T, H, N)                                      \
    template vec<T, N> Attribute<T, H>::to_glm<N>(const H&) const;               \
    template void      Attribute<T, H>::from_glm<N>(const H&, const vec<T, N>&); \
    template Eigen::Matrix<T, N, 1> Attribute<T, H>::to_eigen<N>(const H&)       \
        const;                                                                   \
    template void Attribute<T, H>::from_eigen<N>(                                \
        const H&, const Eigen::Matrix<T, N, 1>&);

// GLM only fully defines vec<N,T> for N=1,2,3,4; N=6,8,12,16 are incomplete.
// Eigen supports arbitrary N. Only instantiate to_glm/from_glm for N=1..4.
#define RXMESH_ATTR_GLM_EIGEN_INST_N(T, H) \
    RXMESH_ATTR_GLM_EIGEN_INST(T, H, 1)    \
    RXMESH_ATTR_GLM_EIGEN_INST(T, H, 2)    \
    RXMESH_ATTR_GLM_EIGEN_INST(T, H, 3)    \
    RXMESH_ATTR_GLM_EIGEN_INST(T, H, 4)

#define RXMESH_ATTR_GLM_EIGEN_INST_ALL(T)         \
    RXMESH_ATTR_GLM_EIGEN_INST_N(T, VertexHandle) \
    RXMESH_ATTR_GLM_EIGEN_INST_N(T, EdgeHandle)   \
    RXMESH_ATTR_GLM_EIGEN_INST_N(T, FaceHandle)   \
    RXMESH_ATTR_GLM_EIGEN_INST_N(T, TetHandle)

RXMESH_ATTR_GLM_EIGEN_INST_ALL(char)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(int8_t)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(uint8_t)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(float)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(double)
// RXMESH_ATTR_GLM_EIGEN_INST_ALL(int)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(uint32_t)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(int32_t)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(uint64_t)
RXMESH_ATTR_GLM_EIGEN_INST_ALL(int64_t)

#undef RXMESH_ATTR_GLM_EIGEN_INST_ALL
#undef RXMESH_ATTR_GLM_EIGEN_INST_N
#undef RXMESH_ATTR_GLM_EIGEN_INST

}  // namespace rxmesh
