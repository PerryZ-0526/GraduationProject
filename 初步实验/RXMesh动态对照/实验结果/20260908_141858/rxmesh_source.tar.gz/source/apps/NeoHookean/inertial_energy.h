#pragma once

#include "rxmesh/rxmesh_static.h"

using namespace rxmesh;

template <typename ProblemT, typename VAttrT, typename T>
void inertial_energy(ProblemT& problem, const VAttrT& x_tilde, const T mass)
{
    T half_mass = T(0.5) * mass;
    problem.template add_term<Op::V, true>(
        [=] __device__(const auto& vh, auto& opt_var) mutable {
            using ActiveT = ACTIVE_TYPE(vh);

            ActiveT E(T(0));

            Eigen::Vector3<ActiveT> xx = opt_var.template active<3>(vh);

            Eigen::Vector3<T> xx_tilde = x_tilde.to_eigen<3>(vh);

            Eigen::Vector3<ActiveT> l = xx - xx_tilde;

            E = half_mass * l.squaredNorm();


            return E;
        });
}