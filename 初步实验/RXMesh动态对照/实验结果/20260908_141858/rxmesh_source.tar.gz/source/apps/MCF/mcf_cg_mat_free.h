#pragma once

#include <cuda_profiler_api.h>
#include "rxmesh/rxmesh_static.h"
#include "rxmesh/util/report.h"
#include "rxmesh/util/timer.h"

#include "mcf_kernels.cuh"

#include "rxmesh/matrix/cg_mat_free_attr_solver.h"
#include "rxmesh/matrix/pcg_mat_free_attr_solver.h"

template <int blockThreads, typename T, typename SolverT>
void run_cg_mat_free(rxmesh::RXMeshStatic& rx,
                     SolverT&              solver,
                     bool                  pcg = false)
{
    using namespace rxmesh;

    // Report
    Report report("MCF_RXMesh");
    report.command_line(Arg.argc, Arg.argv);
    report.device();
    report.system();
    report.model_data(Arg.obj_file_name, rx);
    if (pcg) {
        report.add_member("method", std::string("PCG_MAT_FREE"));
    } else {
        report.add_member("method", std::string("CG_MAT_FREE"));
    }
    report.add_member("application", std::string("MCF"));
    report.add_member("time_step", Arg.time_step);
    report.add_member("tol_abs", Arg.tol_abs);
    report.add_member("tol_rel", Arg.tol_rel);
    report.add_member("use_uniform_laplace", Arg.use_uniform_laplace);
    report.add_member("max_num_iter", Arg.max_num_iter);
    report.add_member("blockThreads", blockThreads);

    if (!rx.is_closed()) {
        RXMESH_ERROR(
            "mcf_rxmesh only takes watertight/closed mesh without boundaries");
        return;
    }

    // Different attributes used throughout the application
    auto input_coord = rx.get_input_vertex_coordinates();

    // RHS
    auto B = rx.add_vertex_attribute<T>("B", 3, rxmesh::DEVICE, rxmesh::AoSoA);
    B->reset(0.0, rxmesh::DEVICE);

    // the unknowns
    auto X = rx.add_vertex_attribute<T>("X", 3, rxmesh::LOCATION_ALL);
    X->copy_from(*input_coord, rxmesh::DEVICE, rxmesh::DEVICE);

    // init kernel to initialize RHS (B)
    LaunchBox<blockThreads> lb;
    rx.prepare_launch_box(
        {Op::VV}, lb, (void*)init_B<T, blockThreads>, !Arg.use_uniform_laplace);
    init_B<T, blockThreads><<<lb.blocks, lb.num_threads, lb.smem_bytes_dyn>>>(
        rx.get_context(), *X, *B, Arg.use_uniform_laplace);

    // matvec launch box
    rx.prepare_launch_box({rxmesh::Op::VV},
                          lb,
                          (void*)matvec<T, blockThreads>,
                          !Arg.use_uniform_laplace);

    float    total_time = 0;
    GPUTimer gtimer;
    GPUTimer timer;
    timer.start();
    gtimer.start();

    solver.pre_solve(*B, *X);

    timer.stop();
    gtimer.stop();

    report.add_member(
        "pre-solve", std::max(timer.elapsed_millis(), gtimer.elapsed_millis()));
    total_time += std::max(timer.elapsed_millis(), gtimer.elapsed_millis());

    timer.start();
    gtimer.start();

    solver.solve(*B, *X);

    timer.stop();
    gtimer.stop();

    report.add_member(
        "solve", std::max(timer.elapsed_millis(), gtimer.elapsed_millis()));
    total_time += std::max(timer.elapsed_millis(), gtimer.elapsed_millis());

    report.add_member("total_time", total_time);


    timer.stop();
    CUDA_ERROR(cudaDeviceSynchronize());
    CUDA_ERROR(cudaProfilerStop());

    RXMESH_INFO("start_residual {}", solver.start_residual());
    RXMESH_INFO("final_residual {}", solver.final_residual());
    RXMESH_INFO("solver {} took {} (ms) and {} iterations (i.e., {} ms/iter)",
                solver.name(),
                timer.elapsed_millis(),
                solver.iter_taken(),
                timer.elapsed_millis() / float(solver.iter_taken()));

    // move output to host
    X->move(rxmesh::DEVICE, rxmesh::HOST);

    // output to obj
    // rxmesh.export_obj("mcf_rxmesh.obj", *X);
#if USE_POLYSCOPE
    auto* ps = rx.get_polyscope_mesh();
    polyscope::registerSurfaceMesh(
        "old mesh",
        ps->vertexPositions.data,
        std::make_tuple(ps->faceIndsEntries.data(), ps->nFaces(), 3));
    ps->updateVertexPositions(*X);

    polyscope::show();
#endif

    // Finalize report
    report.add_member("solver_name", solver.name());
    report.add_member("start_residual", solver.start_residual());
    report.add_member("final_residual", solver.final_residual());
    report.add_member("num_iter_taken", solver.iter_taken());
    report.add_member("total_time (ms)", timer.elapsed_millis());
    TestData td;
    td.test_name   = "MCF";
    td.num_threads = lb.num_threads;
    td.num_blocks  = lb.blocks;
    td.dyn_smem    = lb.smem_bytes_dyn;
    td.static_smem = lb.smem_bytes_static;
    td.num_reg     = lb.num_registers_per_thread;
    td.passed.push_back(true);
    td.time_ms.push_back(timer.elapsed_millis() / float(solver.iter_taken()));
    report.add_test(td);
    report.write(Arg.output_folder + "/rxmesh",
                 "MCF_" + solver.name() + extract_file_name(Arg.obj_file_name));
}


template <typename T>
void mcf_cg_mat_free(rxmesh::RXMeshStatic& rx)
{
    using namespace rxmesh;

    constexpr uint32_t blockThreads = 256;

    // Different attributes used throughout the application
    auto input_coord = rx.get_input_vertex_coordinates();


    LaunchBox<blockThreads> lb;

    // matvec launch box
    rx.prepare_launch_box({rxmesh::Op::VV},
                          lb,
                          (void*)matvec<T, blockThreads>,
                          !Arg.use_uniform_laplace);

    auto mat_vec = [&](const VertexAttribute<T>& in,
                       VertexAttribute<T>&       out,
                       cudaStream_t              stream) {
        rx.run_kernel(lb,
                      matvec<T, blockThreads>,
                      stream,
                      *input_coord,
                      in,
                      out,
                      Arg.use_uniform_laplace,
                      Arg.time_step);
    };

    CGMatFreeAttrSolver<T, VertexHandle> solver(
        rx,
        mat_vec,
        input_coord->get_num_attributes(),
        Arg.max_num_iter,
        Arg.tol_abs,
        Arg.tol_rel);


    run_cg_mat_free<blockThreads, T>(rx, solver);
}


template <typename T>
void mcf_pcg_mat_free(rxmesh::RXMeshStatic& rx)
{
    using namespace rxmesh;

    constexpr uint32_t blockThreads = 256;

    // Different attributes used throughout the application
    auto input_coord = rx.get_input_vertex_coordinates();


    // matvec launch box
    LaunchBox<blockThreads> lb;
    rx.prepare_launch_box({rxmesh::Op::VV},
                          lb,
                          (void*)matvec<T, blockThreads>,
                          !Arg.use_uniform_laplace);

    auto mat_vec = [&](const VertexAttribute<T>& in,
                       VertexAttribute<T>&       out,
                       cudaStream_t              stream) {
        rx.run_kernel(lb,
                      matvec<T, blockThreads>,
                      stream,
                      *input_coord,
                      in,
                      out,
                      Arg.use_uniform_laplace,
                      Arg.time_step);
    };

    // matvec launch box
    LaunchBox<blockThreads> plb;
    rx.prepare_launch_box({rxmesh::Op::VV},
                          plb,
                          (void*)precond_matvec<T, blockThreads>,
                          !Arg.use_uniform_laplace);

    auto precond_mat_vec = [&](const VertexAttribute<T>& in,
                               VertexAttribute<T>&       out,
                               cudaStream_t              stream) {
        rx.run_kernel(plb,
                      precond_matvec<T, blockThreads>,
                      stream,
                      *input_coord,
                      in,
                      out,
                      Arg.use_uniform_laplace,
                      Arg.time_step);
    };

    PCGMatFreeAttrSolver<T, VertexHandle> solver(
        rx,
        mat_vec,
        precond_mat_vec,
        input_coord->get_num_attributes(),
        Arg.max_num_iter,
        Arg.tol_abs,
        Arg.tol_rel);


    run_cg_mat_free<blockThreads, T>(rx, solver, true);
}