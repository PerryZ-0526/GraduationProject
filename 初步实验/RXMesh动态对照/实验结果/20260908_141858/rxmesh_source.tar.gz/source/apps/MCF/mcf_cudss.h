#pragma once
#include "mcf_kernels.cuh"
#include "rxmesh/matrix/cudss_cholesky_solver.h"
#include "rxmesh/rxmesh_static.h"


template <typename T>
void mcf_cudss_chol(rxmesh::RXMeshStatic& rx,
                    rxmesh::PermuteMethod permute_method)
{
    using namespace rxmesh;
    constexpr uint32_t blockThreads = 256;

    uint32_t num_vertices = rx.get_num_vertices();

    auto coords = rx.get_input_vertex_coordinates();

    SparseMatrix<float> A_mat(rx);
    DenseMatrix<float>  B_mat(rx, num_vertices, 3, LOCATION_ALL);

    DenseMatrix<float> X_mat = *coords->to_matrix();


    // B set up
    rx.run_kernel<blockThreads>({Op::VV},
                                mcf_B_setup<float, blockThreads>,
                                *coords,
                                B_mat,
                                Arg.use_uniform_laplace);


    // A set up
    rx.run_kernel<blockThreads>({Op::VV},
                                mcf_A_setup<float, blockThreads>,
                                *coords,
                                A_mat,
                                Arg.use_uniform_laplace,
                                Arg.time_step);

    Report report("MCF_CUDSS_Chol");
    report.command_line(Arg.argc, Arg.argv);
    report.device();
    report.system();
    report.model_data(Arg.obj_file_name, rx);
    report.add_member("method", std::string("cuDSS_Cholesky"));
    report.add_member("application", std::string("MCF"));
    report.add_member("blockThreads", blockThreads);
    report.add_member("PermuteMethod",
                      permute_method_to_string(permute_method));

    RXMESH_INFO("permute_method took {}",
                permute_method_to_string(permute_method));

    float total_time = 0;

    cuDSSCholeskySolver solver(&A_mat, permute_method);

    CPUTimer timer;
    GPUTimer gtimer;

    timer.start();
    gtimer.start();
    solver.permute(rx, B_mat, X_mat);
    timer.stop();
    gtimer.stop();
    RXMESH_INFO("permute took {} (ms), {} (ms)",
                timer.elapsed_millis(),
                gtimer.elapsed_millis());
    report.add_member(
        "permute", std::max(timer.elapsed_millis(), gtimer.elapsed_millis()));
    total_time += std::max(timer.elapsed_millis(), gtimer.elapsed_millis());


    timer.start();
    gtimer.start();
    solver.analyze_pattern();
    timer.stop();
    gtimer.stop();
    RXMESH_INFO("analyze_pattern took {} (ms), {} (ms)",
                timer.elapsed_millis(),
                gtimer.elapsed_millis());
    report.add_member(
        "analyze_pattern",
        std::max(timer.elapsed_millis(), gtimer.elapsed_millis()));
    total_time += std::max(timer.elapsed_millis(), gtimer.elapsed_millis());


    timer.start();
    gtimer.start();
    solver.factorize();
    timer.stop();
    gtimer.stop();
    RXMESH_INFO("factorize took {} (ms), {} (ms)",
                timer.elapsed_millis(),
                gtimer.elapsed_millis());
    report.add_member(
        "factorize", std::max(timer.elapsed_millis(), gtimer.elapsed_millis()));
    total_time += std::max(timer.elapsed_millis(), gtimer.elapsed_millis());

    report.add_member("pre_solve", total_time);

    timer.start();
    gtimer.start();
    solver.solve(B_mat, X_mat);
    timer.stop();
    gtimer.stop();
    RXMESH_INFO("solve took {} (ms), {} (ms)",
                timer.elapsed_millis(),
                gtimer.elapsed_millis());
    report.add_member(
        "solve", std::max(timer.elapsed_millis(), gtimer.elapsed_millis()));
    total_time += std::max(timer.elapsed_millis(), gtimer.elapsed_millis());

    report.add_member("total_time", total_time);

    RXMESH_INFO("total_time {} (ms)", total_time);

    X_mat.move(rxmesh::DEVICE, rxmesh::HOST);

    // copy the results to attributes
    coords->from_matrix(&X_mat);

#if USE_POLYSCOPE
    auto* ps = rx.get_polyscope_mesh();
    polyscope::registerSurfaceMesh(
        "old mesh",
        ps->vertexPositions.data,
        std::make_tuple(ps->faceIndsEntries.data(), ps->nFaces(), 3));
    ps->updateVertexPositions(*coords);
    polyscope::show();
#endif

    B_mat.release();
    X_mat.release();
    A_mat.release();

    // rx.export_obj("cholesky_mcf_result.obj", *coords);

    report.write(Arg.output_folder + "/rxmesh",
                 "MCF_" + solver.name() + extract_file_name(Arg.obj_file_name));
}